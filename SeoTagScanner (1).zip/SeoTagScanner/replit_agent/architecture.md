# Architecture

## Overview

This application is a full-stack SEO analysis tool that allows users to input a URL and receive a comprehensive analysis of the website's SEO performance. The application analyzes meta tags, social media tags, and technical SEO elements, providing a score and recommendations for improvement.

The system follows a client-server architecture with a React frontend and an Express.js backend. The application uses PostgreSQL with Drizzle ORM for data persistence.

## System Architecture

The application follows a modern web application architecture with clear separation between client and server components:

```
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│               │       │               │       │               │
│  React Client │◄─────►│  Express API  │◄─────►│  PostgreSQL   │
│               │       │               │       │               │
└───────────────┘       └───────────────┘       └───────────────┘
                               │
                               ▼
                        ┌───────────────┐
                        │ External Sites│
                        │ (for analysis)│
                        └───────────────┘
```

### Key Design Decisions

1. **Full-Stack TypeScript**: The entire application uses TypeScript for type safety and better developer experience.
2. **Modular Structure**: The codebase is organized into logical modules (client, server, shared) to improve maintainability.
3. **UI Component Library**: The application uses a comprehensive UI component library based on Radix UI primitives and Tailwind CSS.
4. **API-First Backend**: The server exposes REST API endpoints that are consumed by the client.
5. **Type Sharing**: Types are shared between frontend and backend through a shared directory.
6. **Caching Strategy**: Analysis results are cached in memory to improve performance and reduce unnecessary external requests.

## Key Components

### Frontend (React Application)

The frontend is a React application with a component-based architecture:

- **UI Components**: Extensive set of reusable UI components built with Radix UI primitives and styled with Tailwind CSS.
- **State Management**: Uses React Query for server state management and React Context for local state.
- **Routing**: Uses Wouter for lightweight client-side routing.
- **SEO Analyzer Module**: Contains components specific to the SEO analysis functionality.

Key frontend files/directories:
- `/client/src/App.tsx`: Main application component
- `/client/src/components/SEOAnalyzer/`: SEO analysis-specific components
- `/client/src/components/ui/`: Reusable UI components
- `/client/src/lib/`: Utility functions and type definitions
- `/client/src/hooks/`: Custom React hooks

### Backend (Express Application)

The backend is an Express.js application that handles the SEO analysis logic:

- **API Routes**: REST endpoints for analyzing websites.
- **SEO Analyzer**: Logic for fetching and analyzing website HTML and metadata.
- **Storage Service**: Service for caching analysis results.
- **Database Layer**: Drizzle ORM for database interactions.

Key backend files/directories:
- `/server/index.ts`: Entry point for the Express application
- `/server/routes.ts`: API route definitions
- `/server/seoAnalyzer.ts`: SEO analysis logic
- `/server/storage.ts`: Caching service for analysis results
- `/db/index.ts`: Database connection and configuration

### Shared Code

Code shared between frontend and backend:

- `/shared/schema.ts`: Database schema definitions using Drizzle ORM and Zod for validation

### Database Schema

The application uses two main database tables:

1. **users**: Stores user authentication information
   - id (primary key)
   - username (unique)
   - password

2. **seo_analyses**: Stores the results of SEO analyses
   - id (primary key)
   - url
   - title
   - description
   - score
   - created_at
   - meta_tags_count
   - recommendations_count
   - has_canonical
   - has_viewport
   - has_open_graph
   - has_twitter_cards

## Data Flow

### SEO Analysis Flow

1. User enters a URL on the frontend
2. Frontend sends an API request to `/api/analyze` with the URL
3. Backend checks if the analysis is cached
   - If cached, returns the cached result
   - If not cached:
     1. Fetches the HTML from the target website
     2. Parses the HTML to extract meta tags and SEO-related information
     3. Analyzes the extracted data and generates a score and recommendations
     4. Caches the result for future requests
     5. Returns the analysis to the frontend
4. Frontend displays the SEO analysis results including:
   - Overall SEO score
   - Meta tag analysis
   - Social media tag analysis
   - Technical SEO analysis
   - Preview of search engine and social media appearances
   - Recommendations for improvement

## External Dependencies

### Frontend Dependencies

- **React**: UI library
- **Wouter**: Lightweight routing
- **Tanstack Query**: Data fetching and caching
- **Radix UI**: Accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **Cheerio**: HTML parsing for SEO analysis

### Backend Dependencies

- **Express**: Web framework
- **Node-fetch**: HTTP client for fetching external websites
- **Cheerio**: HTML parsing
- **Drizzle ORM**: Database ORM
- **Neon Database**: PostgreSQL client for serverless environments
- **Drizzle-zod**: Schema validation integration

### Database

- **PostgreSQL**: Relational database (via Neon)

## Deployment Strategy

The application is configured for deployment on Replit, with specific configurations in the `.replit` file:

1. **Build Process**:
   - Frontend: Built with Vite (`vite build`)
   - Backend: Bundled with esbuild
   - Combined into a single distribution package

2. **Start Command**: `NODE_ENV=production node dist/index.js`

3. **Development Process**:
   - Dev server: `tsx server/index.ts`
   - Database migrations: `drizzle-kit push`
   - Seed data: `tsx db/seed.ts`

4. **Environment Variables**:
   - `DATABASE_URL`: Required for database connection
   - `NODE_ENV`: Used to determine environment-specific behaviors

This architecture is designed to be scalable, maintainable, and provides a good developer experience while delivering a responsive and functional application to end users.