# User Preferences
This file contains preferences for how the agent will work with the user. It can be updated by both the user and the agent.

Preferred communication style: Simple, everyday language.