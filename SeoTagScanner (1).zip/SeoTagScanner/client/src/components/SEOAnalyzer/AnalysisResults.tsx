import React, { useState, useRef } from "react";
import { SEOAnalysisResult } from "@/lib/types";
import SEOScore from "./SEOScore";
import CoreMetaTags from "./CoreMetaTags";
import SocialMediaTags from "./SocialMediaTags";
import TechnicalTags from "./TechnicalTags";
import PreviewCards from "./PreviewCards";
import Recommendations from "./Recommendations";
import SEOSummary from "./SEOSummary";
import ContentAnalysisSection from "./ContentAnalysis";
import KeywordAnalysis from "./KeywordAnalysis";
import DownloadReport from "./DownloadReport";
import { EyeIcon, BarChart2 } from "lucide-react";

interface AnalysisResultsProps {
  result: SEOAnalysisResult;
}

export default function AnalysisResults({ result }: AnalysisResultsProps) {
  const [viewMode, setViewMode] = useState<"detailed" | "summary">("summary");
  const reportRef = useRef<HTMLDivElement>(null);

  return (
    <div className="w-full">
      <div ref={reportRef} className="w-full">
        <SEOScore 
          score={result.score} 
          tagCount={result.metaTagsCount} 
          websiteUrl={result.url} 
        />

        <div className="mb-4 flex justify-end">
          <div className="inline-flex items-center bg-white rounded-lg border border-neutral-200 shadow-sm">
            <button
              onClick={() => setViewMode("summary")}
              className={`px-3 py-2 rounded-l-lg text-sm font-medium flex items-center gap-1.5 ${viewMode === "summary" ? 'bg-primary text-white' : 'bg-white text-neutral-700 hover:bg-neutral-50'}`}
            >
              <BarChart2 className="h-4 w-4" />
              <span>Summary View</span>
            </button>
            <button
              onClick={() => setViewMode("detailed")}
              className={`px-3 py-2 rounded-r-lg text-sm font-medium flex items-center gap-1.5 ${viewMode === "detailed" ? 'bg-primary text-white' : 'bg-white text-neutral-700 hover:bg-neutral-50'}`}
            >
              <EyeIcon className="h-4 w-4" />
              <span>Detailed View</span>
            </button>
          </div>
        </div>

        {viewMode === "summary" && (
          <SEOSummary result={result} />
        )}

        <div className="space-y-4">
          {/* Top Sections - 2:1 Grid Layout */}
          <div className={`grid grid-cols-1 lg:grid-cols-3 gap-4 ${viewMode === "summary" ? 'mt-3' : ''}`}>
            {/* Left Column - Core Analysis */}
            <div className={`lg:col-span-2 space-y-4 ${viewMode === "summary" ? 'lg:order-1' : ''}`}>
              <CoreMetaTags 
                title={result.title}
                description={result.description}
                viewport={result.viewport}
                canonical={result.canonical}
              />
              <SocialMediaTags 
                openGraph={result.openGraph}
                twitter={result.twitter}
              />
              <TechnicalTags 
                robots={result.robots}
                charset={result.charset}
                language={result.language}
              />
            </div>
            
            {/* Right Column - Previews & Recommendations */}
            <div className={`space-y-4 ${viewMode === "summary" ? 'lg:order-2' : ''}`}>
              <PreviewCards
                title={result.title}
                description={result.description}
                url={result.url}
                openGraph={result.openGraph}
                twitter={result.twitter}
              />
              
              <Recommendations recommendations={result.recommendations} />
            </div>
          </div>
          
          {/* Full-width Sections */}
          <div className="space-y-4 w-full">
            {result.contentAnalysis && (
              <ContentAnalysisSection contentAnalysis={result.contentAnalysis} />
            )}
            <KeywordAnalysis 
              url={result.url}
              title={result.title}
              description={result.description}
              contentAnalysis={result.contentAnalysis}
            />
          </div>
        </div>
      </div>
      
      {/* Download Report Button */}
      <DownloadReport result={result} reportRef={reportRef} />
    </div>
  );
}