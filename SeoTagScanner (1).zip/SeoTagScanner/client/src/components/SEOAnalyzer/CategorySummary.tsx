import React from "react";
import { CheckCircle, AlertTriangle, XCircle, Info } from "lucide-react";

interface CategoryScore {
  score: number;
  label: string;
  status: "good" | "warning" | "error" | "info";
  description: string;
  count?: {
    total: number;
    good: number;
  };
}

interface CategorySummaryProps {
  categories: CategoryScore[];
}

export default function CategorySummary({ categories }: CategorySummaryProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "good":
        return <CheckCircle className="h-5 w-5 text-secondary" />;
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-warning" />;
      case "error":
        return <XCircle className="h-5 w-5 text-destructive" />;
      case "info":
        return <Info className="h-5 w-5 text-primary" />;
      default:
        return null;
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case "good":
        return "bg-secondary/5 border-secondary/20";
      case "warning":
        return "bg-warning/5 border-warning/20";
      case "error":
        return "bg-destructive/5 border-destructive/20";
      case "info":
        return "bg-primary/5 border-primary/20";
      default:
        return "bg-neutral-50 border-neutral-200";
    }
  };

  const getScoreColor = (status: string) => {
    switch (status) {
      case "good":
        return "text-secondary";
      case "warning":
        return "text-warning";
      case "error":
        return "text-destructive";
      case "info":
        return "text-primary";
      default:
        return "text-neutral-700";
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-3 mb-3 w-full">
      <h2 className="text-lg font-semibold text-neutral-800 mb-3 text-center">SEO Category Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        {categories.map((category, index) => (
          <div 
            key={index} 
            className={`rounded-lg border p-3 ${getStatusClass(category.status)} transition h-[100px] flex flex-col`}
          >
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center flex-shrink-0">
                <div className="flex-shrink-0">
                  {getStatusIcon(category.status)}
                </div>
                <h3 className="font-medium text-neutral-800 ml-2 text-sm">{category.label}</h3>
              </div>
              {category.score !== undefined && (
                <div className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-white shadow-sm border border-neutral-100">
                  <span className={`text-xs font-semibold ${getScoreColor(category.status)}`}>
                    {category.score}
                  </span>
                </div>
              )}
            </div>
            <p className="text-xs text-neutral-600 flex-grow">{category.description}</p>
            {category.count && (
              <div className="mt-1 flex items-center justify-start text-xs text-neutral-500">
                <span className="font-medium">{category.count.good}</span>
                <span className="mx-1">of</span>
                <span className="font-medium">{category.count.total}</span>
                <span className="ml-1">tags implemented</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
