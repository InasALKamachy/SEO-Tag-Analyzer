import { ContentAnalysis as ContentAnalysisType } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Heading, 
  Image, 
  Link2, 
  Check, 
  AlertTriangle, 
  X, 
  FileText 
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface ContentAnalysisProps {
  contentAnalysis: ContentAnalysisType;
}

export default function ContentAnalysisSection({ contentAnalysis }: ContentAnalysisProps) {
  const { headings, images, links, contentLength, status } = contentAnalysis;
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "good":
        return <Badge className="bg-green-500 text-white">Good</Badge>;
      case "warning":
        return <Badge className="bg-amber-500 text-white">Needs Improvement</Badge>;
      case "error":
        return <Badge className="bg-red-500 text-white">Poor</Badge>;
      default:
        return <Badge className="bg-slate-500 text-white">Not Analyzed</Badge>;
    }
  };
  
  const getIconByStatus = (status: string) => {
    switch (status) {
      case "good":
        return <Check className="h-5 w-5 text-green-500" />;
      case "warning":
      case "needs-improvement":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case "error":
      case "poor":
        return <X className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };
  
  // Calculate percentages for visualizations
  const altTextPercentage = images.count > 0 ? (images.withAlt / images.count) * 100 : 0;
  const internalLinksPercentage = links.count > 0 ? (links.internal / links.count) * 100 : 0;
  const externalLinksPercentage = links.count > 0 ? (links.external / links.count) * 100 : 0;
  
  return (
    <Card className="w-full max-w-full">
      <CardHeader className="px-4 py-3 border-b border-neutral-200">
        <CardTitle className="flex items-center gap-2 text-base">
          <FileText className="h-5 w-5" />
          Content Analysis
          {getStatusBadge(status)}
        </CardTitle>
        <CardDescription className="text-sm">
          Analysis of page content structure, headings, images, and links
        </CardDescription>
      </CardHeader>
      <CardContent className="px-4 py-4">
        <div className="space-y-6">
          {/* Heading Structure */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Heading className="h-5 w-5 text-blue-500" />
              <h3 className="text-base font-medium">Heading Structure</h3>
              {getIconByStatus(headings.hasProperStructure ? "good" : "warning")}
            </div>
            
            <div className="grid grid-cols-3 gap-4 mt-2">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] justify-between">
                <div className="text-sm font-medium text-center">H1 Headings</div>
                <div className="text-3xl font-bold text-center">{headings.h1Count}</div>
                {headings.h1Count === 0 && (
                  <p className="text-xs text-red-500 text-center">Missing H1</p>
                )}
                {headings.h1Count > 1 && (
                  <p className="text-xs text-amber-500 text-center">Multiple H1s</p>
                )}
                {headings.h1Count === 1 && (
                  <p className="text-xs text-green-500 text-center">Good structure</p>
                )}
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] justify-between">
                <div className="text-sm font-medium text-center">H2 Headings</div>
                <div className="text-3xl font-bold text-center">{headings.h2Count}</div>
                {headings.h2Count === 0 && contentLength && contentLength > 300 && (
                  <p className="text-xs text-amber-500 text-center">Add subheadings</p>
                )}
                {headings.h2Count > 0 && (
                  <p className="text-xs text-green-500 text-center">Subheadings ✓</p>
                )}
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] justify-between">
                <div className="text-sm font-medium text-center">H3 Headings</div>
                <div className="text-3xl font-bold text-center">{headings.h3Count}</div>
                <p className="text-xs text-neutral-500 text-center">&nbsp;</p>
              </div>
            </div>
            
            {headings.h1Content && headings.h1Content.length > 0 && (
              <div className="mt-3">
                <h4 className="text-sm font-medium text-muted-foreground mb-1">Main Heading:</h4>
                <div className="bg-slate-50 p-3 rounded-md border border-slate-200 text-sm">
                  {headings.h1Content[0]}
                </div>
              </div>
            )}
          </div>
          
          <Separator className="my-4" />
          
          {/* Image Analysis */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Image className="h-5 w-5 text-blue-500" />
              <h3 className="text-base font-medium">Image Optimization</h3>
              {getIconByStatus(images.altTextQuality || "not-analyzed")}
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] justify-between">
                <div className="text-sm font-medium text-center">Total Images</div>
                <div className="text-3xl font-bold text-center">{images.count}</div>
                {images.withoutAlt > 0 && (
                  <p className="text-xs text-amber-500 text-center">{images.withoutAlt} missing alt text</p>
                )}
                {images.withoutAlt === 0 && images.count > 0 && (
                  <p className="text-xs text-green-500 text-center">All images have alt text</p>
                )}
                {images.count === 0 && (
                  <p className="text-xs text-neutral-500 text-center">No images detected</p>
                )}
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] col-span-full">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Alt Text</span>
                  <span className="text-sm text-muted-foreground">{images.withAlt}/{images.count}</span>
                </div>
                <div className="flex-grow flex flex-col justify-center">
                  <Progress value={altTextPercentage} className="h-2.5" />
                  <div className="mt-2 text-center text-sm font-medium">
                    {images.count > 0 ? Math.round(altTextPercentage) : 0}%
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          {/* Link Analysis */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Link2 className="h-5 w-5 text-blue-500" />
              <h3 className="text-base font-medium">Link Analysis</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px] justify-between">
                <div className="text-sm font-medium text-center">Total Links</div>
                <div className="text-3xl font-bold text-center">{links.count}</div>
                {links.count === 0 && (
                  <p className="text-xs text-amber-500 text-center">No links detected</p>
                )}
                {links.count > 0 && (
                  <p className="text-xs text-neutral-500 text-center">&nbsp;</p>
                )}
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px]">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Internal Links</span>
                  <span className="text-sm text-muted-foreground">{links.internal}</span>
                </div>
                <div className="flex-grow flex flex-col justify-center">
                  <Progress value={internalLinksPercentage} className="h-2.5 bg-blue-200" />
                  <div className="mt-2 text-center text-sm font-medium">
                    {links.count > 0 ? Math.round(internalLinksPercentage) : 0}%
                  </div>
                </div>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[100px]">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">External Links</span>
                  <span className="text-sm text-muted-foreground">{links.external}</span>
                </div>
                <div className="flex-grow flex flex-col justify-center">
                  <Progress value={externalLinksPercentage} className="h-2.5 bg-purple-200" />
                  <div className="mt-2 text-center text-sm font-medium">
                    {links.count > 0 ? Math.round(externalLinksPercentage) : 0}%
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          {/* Content Length */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-500" />
              <h3 className="text-base font-medium">Content Length</h3>
            </div>
            
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 flex flex-col h-[150px]">
              <div className="flex justify-between mb-2">
                <div className="text-sm font-medium">Total Content Length</div>
                {contentLength && (
                  <div>
                    {contentLength < 300 ? (
                      <Badge className="bg-red-500 text-white">Thin Content</Badge>
                    ) : contentLength < 800 ? (
                      <Badge className="bg-amber-500 text-white">Moderate Content</Badge>
                    ) : (
                      <Badge className="bg-green-500 text-white">Rich Content</Badge>
                    )}
                  </div>
                )}
              </div>
              
              <div className="text-5xl font-bold text-center my-5">{contentLength ? contentLength.toLocaleString() : "N/A"}</div>
              
              <p className="text-sm text-center">
                {contentLength ? (
                  contentLength < 300 
                    ? "Your content is quite thin. Search engines typically prefer pages with substantial content."
                    : contentLength < 800 
                      ? "Your content has a moderate length. Consider expanding with more information."
                      : "Your content is substantial, which is generally good for SEO."
                ) : (
                  "No content length data available"
                )}
              </p>
            </div>
          </div>
          
          {/* Recommendations Accordion */}
          {contentAnalysis.recommendations && contentAnalysis.recommendations.length > 0 && (
            <>
              <Separator className="my-4" />
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <h3 className="text-base font-medium">Content Recommendations</h3>
                </div>
                <Accordion type="single" collapsible className="w-full">
                  {contentAnalysis.recommendations.map((rec, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="border rounded-md border-slate-200 mb-2">
                      <AccordionTrigger className="flex items-center px-4 py-3 hover:bg-slate-50">
                        <div className="flex items-center gap-2">
                          {rec.priority === "high" ? (
                            <Badge className="bg-red-500 text-white">High Priority</Badge>
                          ) : rec.priority === "medium" ? (
                            <Badge className="bg-amber-500 text-white">Medium Priority</Badge>
                          ) : (
                            <Badge className="bg-blue-500 text-white">Low Priority</Badge>
                          )}
                          <span className="font-medium">{rec.title}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground px-4 py-3">
                        <p className="text-sm">{rec.description}</p>
                        {rec.example && (
                          <div className="mt-3 p-3 bg-slate-50 rounded-md text-sm font-mono overflow-x-auto border border-slate-200">
                            {rec.example}
                          </div>
                        )}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </>
          )}
          
          {/* Education Section */}
          <Separator className="my-4" />
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-950 p-5 rounded-lg mt-4 border border-blue-100">
            <h3 className="text-lg font-medium mb-3">Why Content Analysis Matters</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Well-structured content does more than just look good—it directly impacts your SEO performance:
            </p>
            <ul className="text-sm space-y-3">
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Proper heading structure</strong> helps search engines understand your content hierarchy and improves accessibility</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Alt text for images</strong> makes your content accessible and provides additional keyword opportunities</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Internal linking</strong> helps distribute page authority and keeps visitors on your site longer</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Substantial content</strong> typically ranks better as it provides more value to readers</span>
              </li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}