import React, { useState } from "react";
import { OpenGraphTags, TwitterTags } from "@/lib/types";
import { ChevronDown, ChevronUp, Check, X } from "lucide-react";

interface SocialMediaTagsProps {
  openGraph: OpenGraphTags;
  twitter: TwitterTags;
}

export default function SocialMediaTags({ openGraph, twitter }: SocialMediaTagsProps) {
  const [expanded, setExpanded] = useState(true);

  // Calculate social tag scores
  const getOpenGraphScore = () => {
    let score = 0;
    let totalTags = 4; // title, description, image, url
    
    if (openGraph.title) score += 25;
    if (openGraph.description) score += 25;
    if (openGraph.image) score += 25;
    if (openGraph.url) score += 25;
    
    return Math.round(score);
  };
  
  const getTwitterScore = () => {
    let score = 0;
    let totalTags = 4; // card, title, description, image
    
    if (twitter.card) score += 25;
    if (twitter.title) score += 25;
    if (twitter.description) score += 25;
    if (twitter.image) score += 25;
    
    return Math.round(score);
  };
  
  // Calculate average for both platforms
  const getSocialScore = () => {
    return Math.round((getOpenGraphScore() + getTwitterScore()) / 2);
  };
  
  // Get the status based on score
  const getScoreStatus = (score: number) => {
    if (score >= 75) return "good";
    if (score >= 40) return "warning";
    return "error";
  };
  
  const getStatusColor = (status: string) => {
    switch(status) {
      case "good": return "text-secondary";
      case "warning": return "text-warning";
      case "error": return "text-destructive";
      default: return "text-neutral-500";
    }
  };
  
  // Count implemented tags
  const ogTagsCount = [openGraph.title, openGraph.description, openGraph.image, openGraph.url].filter(Boolean).length;
  const twitterTagsCount = [twitter.card, twitter.title, twitter.description, twitter.image].filter(Boolean).length;
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div 
        className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200 flex justify-between items-center cursor-pointer hover:bg-neutral-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 text-primary">
            <span className="text-sm font-semibold">{getSocialScore()}</span>
          </div>
          <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">Social Media Tags</h3>
        </div>
        {expanded ? <ChevronUp className="h-5 w-5 text-neutral-500" /> : <ChevronDown className="h-5 w-5 text-neutral-500" />}
      </div>
      
      {expanded && (
        <div className="p-4 sm:p-6">
          {/* Social Media Tag Scores */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* Facebook Open Graph Score */}
            <div className="border rounded-lg p-4 overflow-hidden relative bg-gradient-to-br from-blue-500/5 to-blue-600/5 border-blue-200">
              <div className="flex items-center mb-3">
                <div className="bg-blue-600 text-white rounded-lg h-8 w-8 flex items-center justify-center mr-2 shadow-sm">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9.5 3H12V7H9.5C7.57 7 6 8.57 6 10.5V13H3V17H6V21H10V17H12.5L13 13H10V10.5C10 10.22 10.22 10 10.5 10H13V6.12C11.71 5.7 10.62 5.5 9.5 5.5C7.02 5.5 5 7.02 5 9.5V11H2V15H5V21H9V15H11.5L12 11H9V9.5C9 9.22 9.22 9 9.5 9H13" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Facebook Open Graph</h4>
                  <p className="text-neutral-500 text-xs">{ogTagsCount} of 4 tags implemented</p>
                </div>
                <div className="ml-auto bg-white rounded-full h-10 w-10 flex items-center justify-center border border-neutral-200 shadow-sm">
                  <span className={`font-bold ${getStatusColor(getScoreStatus(getOpenGraphScore()))}`}>{getOpenGraphScore()}</span>
                </div>
              </div>
              
              {/* Tag status indicators */}
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {openGraph.title ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">og:title</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {openGraph.description ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">og:description</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {openGraph.image ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">og:image</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {openGraph.url ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">og:url</span>
                </div>
              </div>
            </div>
            
            {/* Twitter Card Score */}
            <div className="border rounded-lg p-4 overflow-hidden relative bg-gradient-to-br from-blue-400/5 to-blue-500/5 border-blue-200">
              <div className="flex items-center mb-3">
                <div className="bg-blue-400 text-white rounded-lg h-8 w-8 flex items-center justify-center mr-2 shadow-sm">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22 5.8a8.49 8.49 0 0 1-2.36.64 4.13 4.13 0 0 0 1.81-2.27 8.21 8.21 0 0 1-2.61 1 4.1 4.1 0 0 0-7 3.74 11.64 11.64 0 0 1-8.45-4.29 4.16 4.16 0 0 0-.55 2.07 4.09 4.09 0 0 0 1.82 3.41 4.05 4.05 0 0 1-1.86-.51v.05a4.1 4.1 0 0 0 3.3 4 3.93 3.93 0 0 1-1.1.17 4 4 0 0 1-.77-.07 4.11 4.11 0 0 0 3.83 2.84A8.22 8.22 0 0 1 3 18.34a7.93 7.93 0 0 1-1-.06 11.57 11.57 0 0 0 6.29 1.85A11.59 11.59 0 0 0 20 8.45v-.53a8.43 8.43 0 0 0 2-2.12Z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Twitter Card</h4>
                  <p className="text-neutral-500 text-xs">{twitterTagsCount} of 4 tags implemented</p>
                </div>
                <div className="ml-auto bg-white rounded-full h-10 w-10 flex items-center justify-center border border-neutral-200 shadow-sm">
                  <span className={`font-bold ${getStatusColor(getScoreStatus(getTwitterScore()))}`}>{getTwitterScore()}</span>
                </div>
              </div>
              
              {/* Tag status indicators */}
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {twitter.card ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">twitter:card</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {twitter.title ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">twitter:title</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {twitter.description ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">twitter:description</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white rounded p-2 border border-neutral-200">
                  {twitter.image ? 
                    <Check className="h-4 w-4 text-secondary" /> : 
                    <X className="h-4 w-4 text-destructive" />}
                  <span className="text-xs font-medium">twitter:image</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 bg-neutral-50 p-4 rounded-lg border border-neutral-200">
            <h4 className="font-medium text-sm mb-2">Why Social Tags Matter</h4>
            <p className="text-xs sm:text-sm text-neutral-600 mb-2">
              Social media tags control how your content appears when shared on platforms like Facebook, Twitter, and LinkedIn.
              Well-implemented tags increase click-through rates and engagement.  
            </p>
            {(ogTagsCount < 4 || twitterTagsCount < 4) && (
              <div className="text-xs bg-yellow-50 p-2 rounded border border-yellow-200 text-yellow-700">
                <span className="font-semibold">Recommendation:</span> Implement all missing social media tags for better visibility on social platforms.
              </div>
            )}
          </div>
          
          {/* Full tag code details (collapsible) */}
          <details className="mt-6 border rounded-lg">
            <summary className="cursor-pointer p-3 bg-neutral-50 font-medium text-sm text-neutral-700 flex items-center">
              <span className="mr-2">
                <svg className="inline w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="20" height="16" x="2" y="4" rx="2" /><path d="m9 10 3 3 3-3" /></svg>
              </span>
              View All Tag Code
            </summary>
            <div className="p-3 border-t text-xs">
              <div className="mb-4">
                <h5 className="font-medium text-neutral-700 mb-2">Open Graph Tags</h5>
                <div className="space-y-2">
                  {/* og:title */}
                  {openGraph.title ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta property="og:title" content="{openGraph.title}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No og:title tag found
                    </div>
                  )}
                  
                  {/* og:description */}
                  {openGraph.description ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta property="og:description" content="{openGraph.description}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No og:description tag found
                    </div>
                  )}
                  
                  {/* og:image */}
                  {openGraph.image ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta property="og:image" content="{openGraph.image}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No og:image tag found
                    </div>
                  )}
                  
                  {/* og:url */}
                  {openGraph.url ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta property="og:url" content="{openGraph.url}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No og:url tag found
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <h5 className="font-medium text-neutral-700 mb-2">Twitter Card Tags</h5>
                <div className="space-y-2">
                  {/* twitter:card */}
                  {twitter.card ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta name="twitter:card" content="{twitter.card}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No twitter:card tag found
                    </div>
                  )}
                  
                  {/* twitter:title */}
                  {twitter.title ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta name="twitter:title" content="{twitter.title}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No twitter:title tag found
                    </div>
                  )}
                  
                  {/* twitter:description */}
                  {twitter.description ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta name="twitter:description" content="{twitter.description}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No twitter:description tag found
                    </div>
                  )}
                  
                  {/* twitter:image */}
                  {twitter.image ? (
                    <div className="bg-neutral-50 p-2 rounded-lg code overflow-auto border border-neutral-200">
                      &lt;meta name="twitter:image" content="{twitter.image}"&gt;
                    </div>
                  ) : (
                    <div className="bg-neutral-50 p-2 rounded-lg border border-dashed border-destructive/50 text-neutral-500 italic">
                      No twitter:image tag found
                    </div>
                  )}
                </div>
              </div>
            </div>
          </details>
        </div>
      )}
    </div>
  );
}
