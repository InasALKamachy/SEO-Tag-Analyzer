import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { SEOAnalysisResult } from '@/lib/types';
import { jsPDF } from 'jspdf';
import { useToast } from '@/hooks/use-toast';

interface DownloadReportProps {
  result: SEOAnalysisResult;
  reportRef: React.RefObject<HTMLDivElement>;
}

export default function DownloadReport({ result, reportRef }: DownloadReportProps) {
  const { toast } = useToast();

  const generatePDF = async () => {
    if (!reportRef.current) return;
    
    try {
      // Display loading toast
      toast({
        title: 'Generating PDF',
        description: 'Please wait while we generate your report...',
      });
      
      // Create a new PDF document (A4 size)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });
      
      // Add a title with styling
      pdf.setFillColor(245, 247, 250);
      pdf.rect(0, 0, pdf.internal.pageSize.getWidth(), 40, 'F');
      pdf.setDrawColor(200, 200, 200);
      pdf.line(10, 40, pdf.internal.pageSize.getWidth() - 10, 40);
      
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(24);
      pdf.setTextColor(25, 25, 112);
      pdf.text('SEO Analysis Report', 105, 20, { align: 'center' });
      
      // Add website URL and date with styling
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(12);
      pdf.setTextColor(60, 60, 60);
      pdf.text(`Website: ${result.url}`, 105, 30, { align: 'center' });
      pdf.text(`Generated: ${new Date().toLocaleDateString()}`, 105, 37, { align: 'center' });
      
      // Add summary section
      let yPosition = 50;
      
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(16);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Summary', 15, yPosition);
      yPosition += 10;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(12);
      pdf.setTextColor(60, 60, 60);
      pdf.text(`Overall SEO Score: ${result.score}/100`, 15, yPosition);
      yPosition += 7;
      pdf.text(`Meta Tags Found: ${result.metaTagsCount}`, 15, yPosition);
      yPosition += 7;
      
      // Draw score gauge - a properly styled circular gauge like in the image
      const gaugeX = 160;
      const gaugeY = 65;
      const gaugeRadius = 20;
      
      // Define score colors - use primary blue for scores in 70-89 range
      const scoreColor = result.score >= 90 ? [46, 204, 113] : 
                          result.score >= 70 ? [59, 130, 246] : 
                          result.score >= 50 ? [251, 146, 60] : 
                          [231, 76, 60];
      
      // Draw background circle (light gray)
      pdf.setDrawColor(245, 245, 245);
      pdf.setFillColor(245, 245, 245);
      pdf.circle(gaugeX, gaugeY, gaugeRadius, 'FD');
      
      // Draw the gauge arc - we'll fake this with segments
      const segments = 36; // number of segments to draw (for smoothness)
      const scorePercent = result.score / 100;
      const scoreSegments = Math.floor(scorePercent * segments);
      
      // Calculate which segments to color
      pdf.setDrawColor(scoreColor[0], scoreColor[1], scoreColor[2]);
      pdf.setFillColor(scoreColor[0], scoreColor[1], scoreColor[2]);
      
      // Draw colored segments
      for (let i = 0; i < scoreSegments; i++) {
        const angle = (i / segments) * 2 * Math.PI;
        const nextAngle = ((i + 1) / segments) * 2 * Math.PI;
        
        const x1 = gaugeX + (gaugeRadius - 2) * Math.sin(angle);
        const y1 = gaugeY - (gaugeRadius - 2) * Math.cos(angle);
        const x2 = gaugeX + (gaugeRadius - 2) * Math.sin(nextAngle);
        const y2 = gaugeY - (gaugeRadius - 2) * Math.cos(nextAngle);
        
        pdf.setLineWidth(4);
        pdf.line(x1, y1, x2, y2);
      }
      
      // Add white center circle
      pdf.setDrawColor(255, 255, 255);
      pdf.setFillColor(255, 255, 255);
      pdf.circle(gaugeX, gaugeY, gaugeRadius - 5, 'FD');
      
      // Draw "SEO Score" text
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(9);
      pdf.setTextColor(100, 100, 100);
      pdf.text("SEO Score", gaugeX, gaugeY - 4, { align: 'center' });
      
      // Draw score text
      pdf.setFontSize(18);
      pdf.setTextColor(40, 40, 40);
      pdf.setFont("helvetica", "bold");
      pdf.text(`${result.score}`, gaugeX, gaugeY + 6, { align: 'center' });
      
      // Title section
      yPosition += 15;
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Title Tag', 15, yPosition);
      yPosition += 7;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);
      pdf.text(`Content: ${result.title.content}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Length: ${result.title.length} characters`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Status: ${result.title.status.toUpperCase()}`, 15, yPosition);
      yPosition += 10;
      
      // Description section
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Meta Description', 15, yPosition);
      yPosition += 7;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);
      if (result.description.content) {
        const descriptionLines = pdf.splitTextToSize(result.description.content, 180);
        pdf.text(`Content: ${descriptionLines[0]}${descriptionLines.length > 1 ? '...' : ''}`, 15, yPosition);
        yPosition += 6;
      } else {
        pdf.text('Content: Not found', 15, yPosition);
        yPosition += 6;
      }
      pdf.text(`Length: ${result.description.length} characters`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Status: ${result.description.status.toUpperCase()}`, 15, yPosition);
      yPosition += 10;
      
      // Social tags summary
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Social Media Tags', 15, yPosition);
      yPosition += 7;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);
      pdf.text(`Open Graph Tags: ${result.openGraph.title ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Twitter Card Tags: ${result.twitter.card ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 10;
      
      // Top Recommendations
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Top Recommendations', 15, yPosition);
      yPosition += 7;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);
      
      // Get top 3 high priority recommendations
      const topRecs = result.recommendations
        .filter(rec => rec.priority === 'high')
        .slice(0, 3);
        
      if (topRecs.length > 0) {
        topRecs.forEach((rec, index) => {
          const recLines = pdf.splitTextToSize(`${index + 1}. ${rec.title}: ${rec.description}`, 180);
          pdf.text(recLines, 15, yPosition);
          yPosition += recLines.length * 6 + 4;
        });
      } else {
        pdf.text('No high-priority recommendations found.', 15, yPosition);
        yPosition += 6;
      }
      
      // Add second page for detailed analysis
      pdf.addPage();
      
      // Header for second page
      pdf.setFillColor(245, 247, 250);
      pdf.rect(0, 0, pdf.internal.pageSize.getWidth(), 20, 'F');
      pdf.setDrawColor(200, 200, 200);
      pdf.line(10, 20, pdf.internal.pageSize.getWidth() - 10, 20);
      
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(16);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Detailed SEO Analysis', 105, 15, { align: 'center' });
      
      yPosition = 30;
      
      // Technical SEO section
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(14);
      pdf.setTextColor(25, 25, 112);
      pdf.text('Technical SEO', 15, yPosition);
      yPosition += 7;
      
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(11);
      pdf.setTextColor(60, 60, 60);
      pdf.text(`Canonical Tag: ${result.canonical.content ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Viewport Tag: ${result.viewport.content ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Robots Tag: ${result.robots.content ? 'Present' : 'Not required'}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Language Tag: ${result.language.content ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 6;
      pdf.text(`Charset: ${result.charset.content ? 'Present' : 'Missing'}`, 15, yPosition);
      yPosition += 10;
      
      // Content Analysis section if available
      if (result.contentAnalysis) {
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(14);
        pdf.setTextColor(25, 25, 112);
        pdf.text('Content Analysis', 15, yPosition);
        yPosition += 7;
        
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(11);
        pdf.setTextColor(60, 60, 60);
        
        // Headings
        pdf.text(`H1 Tags: ${result.contentAnalysis.headings.h1Count}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`H2 Tags: ${result.contentAnalysis.headings.h2Count}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`H3 Tags: ${result.contentAnalysis.headings.h3Count}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`Proper Heading Structure: ${result.contentAnalysis.headings.hasProperStructure ? 'Yes' : 'No'}`, 15, yPosition);
        yPosition += 6;
        
        // Images
        pdf.text(`Images: ${result.contentAnalysis.images.count}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`Images with Alt Text: ${result.contentAnalysis.images.withAlt}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`Images without Alt Text: ${result.contentAnalysis.images.withoutAlt}`, 15, yPosition);
        yPosition += 6;
        
        // Links
        pdf.text(`Links: ${result.contentAnalysis.links.count}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`Internal Links: ${result.contentAnalysis.links.internal}`, 15, yPosition);
        yPosition += 6;
        pdf.text(`External Links: ${result.contentAnalysis.links.external}`, 15, yPosition);
        yPosition += 6;
        
        // Content length
        if (result.contentAnalysis.contentLength) {
          pdf.text(`Content Length: ${result.contentAnalysis.contentLength} words`, 15, yPosition);
          yPosition += 6;
        }
      }
      
      // List all recommendations
      pdf.addPage();
      
      // Header for recommendations page
      pdf.setFillColor(245, 247, 250);
      pdf.rect(0, 0, pdf.internal.pageSize.getWidth(), 20, 'F');
      pdf.setDrawColor(200, 200, 200);
      pdf.line(10, 20, pdf.internal.pageSize.getWidth() - 10, 20);
      
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(16);
      pdf.setTextColor(25, 25, 112);
      pdf.text('SEO Recommendations', 105, 15, { align: 'center' });
      
      yPosition = 30;
      
      // Sort recommendations by priority
      const sortedRecs = [...result.recommendations].sort((a, b) => {
        const priorityOrder = { high: 1, medium: 2, low: 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      });
      
      // Add recommendations with priority badges
      sortedRecs.forEach((rec, index) => {
        // Priority badge
        const priorityColor = rec.priority === 'high' ? [231, 76, 60] : 
                            rec.priority === 'medium' ? [255, 159, 0] : [46, 204, 113];
        
        pdf.setFillColor(priorityColor[0], priorityColor[1], priorityColor[2]);
        pdf.roundedRect(15, yPosition - 5, 30, 7, 2, 2, 'F');
        
        pdf.setTextColor(255, 255, 255);
        pdf.setFontSize(9);
        pdf.setFont("helvetica", "bold");
        pdf.text(rec.priority.toUpperCase(), 30, yPosition - 0.5, { align: 'center' });
        
        // Recommendation title
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(12);
        pdf.setTextColor(25, 25, 112);
        pdf.text(`${index + 1}. ${rec.title}`, 50, yPosition);
        yPosition += 7;
        
        // Recommendation description
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(11);
        pdf.setTextColor(60, 60, 60);
        const descLines = pdf.splitTextToSize(rec.description, 150);
        pdf.text(descLines, 50, yPosition);
        yPosition += descLines.length * 5 + 7;
        
        // Add example if available
        if (rec.example) {
          pdf.setFontSize(10);
          pdf.setTextColor(100, 100, 100);
          pdf.text('Example:', 50, yPosition);
          yPosition += 5;
          
          pdf.setFontSize(9);
          pdf.setTextColor(125, 125, 125);
          const exampleLines = pdf.splitTextToSize(rec.example, 150);
          pdf.text(exampleLines, 50, yPosition);
          yPosition += exampleLines.length * 5 + 10;
        } else {
          yPosition += 10;
        }
        
        // Add a page break if needed
        if (yPosition > 270) {
          pdf.addPage();
          
          // Header for additional recommendation pages
          pdf.setFillColor(245, 247, 250);
          pdf.rect(0, 0, pdf.internal.pageSize.getWidth(), 20, 'F');
          pdf.setDrawColor(200, 200, 200);
          pdf.line(10, 20, pdf.internal.pageSize.getWidth() - 10, 20);
          
          pdf.setFont("helvetica", "bold");
          pdf.setFontSize(16);
          pdf.setTextColor(25, 25, 112);
          pdf.text('SEO Recommendations (Continued)', 105, 15, { align: 'center' });
          
          yPosition = 30;
        }
      });
      
      // Add footer to all pages
      const pageCount = Object.keys(pdf.internal.pages).length - 1;
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        pdf.setFontSize(10);
        pdf.setTextColor(150, 150, 150);
        pdf.text(`Page ${i} of ${pageCount}`, pdf.internal.pageSize.getWidth() - 20, pdf.internal.pageSize.getHeight() - 10);
        pdf.text('Generated by SEO Analyzer', 20, pdf.internal.pageSize.getHeight() - 10);
      }
      
      // Download the PDF
      pdf.save(`seo-report-${result.url.replace(/https?:\/\/|www\.|\//g, '')}.pdf`);
      
      // Show success toast
      toast({
        title: 'PDF Generated',
        description: 'Your SEO report has been downloaded',
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: 'PDF Generation Failed',
        description: 'There was a problem generating your PDF report',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="flex gap-3 justify-end mt-4">
      <Button onClick={generatePDF}>
        <Download className="mr-2 h-4 w-4" /> 
        Download PDF
      </Button>
    </div>
  );
}
