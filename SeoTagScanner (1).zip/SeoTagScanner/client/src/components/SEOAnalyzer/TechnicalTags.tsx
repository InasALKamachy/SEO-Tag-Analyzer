import React, { useState } from "react";
import { ChevronDown, ChevronUp, Globe, Bot, Code, Languages } from "lucide-react";

interface TechnicalTagsProps {
  robots: {
    content: string | null;
    status: "good" | "warning" | "error" | "not-required";
  };
  charset: {
    content: string | null;
    status: "good" | "warning" | "error";
  };
  language: {
    content: string | null;
    status: "good" | "warning" | "error";
  };
}

export default function TechnicalTags({ robots, charset, language }: TechnicalTagsProps) {
  const [expanded, setExpanded] = useState(true);

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "good": return "Present";
      case "warning": return "Needs Improvement";
      case "error": return "Missing";
      case "not-required": return "Not Required";
      default: return "Unknown";
    }
  };
  
  const getStatusClass = (status: string) => {
    switch (status) {
      case "good": return "bg-secondary/10 text-secondary";
      case "warning": return "bg-warning/10 text-warning";
      case "error": return "bg-destructive/10 text-destructive";
      case "not-required": return "bg-neutral-100 text-neutral-500";
      default: return "bg-neutral-100 text-neutral-500";
    }
  };
  
  const getCardClass = (status: string) => {
    switch (status) {
      case "good": return "border-secondary/20 bg-secondary/5";
      case "warning": return "border-warning/20 bg-warning/5";
      case "error": return "border-destructive/20 bg-destructive/5";
      case "not-required": return "border-neutral-200 bg-neutral-50";
      default: return "border-neutral-200 bg-neutral-50";
    }
  };
  
  const getStatusIcon = (type: string, status: string) => {
    const commonClasses = "h-8 w-8 p-1.5 rounded-full";
    let icon;
    
    switch (type) {
      case "robots":
        icon = <Bot className="h-full w-full" />;
        break;
      case "hreflang":
        icon = <Globe className="h-full w-full" />;
        break;
      case "charset":
        icon = <Code className="h-full w-full" />;
        break;
      case "language":
        icon = <Languages className="h-full w-full" />;
        break;
      default:
        icon = <Code className="h-full w-full" />;
    }
    
    switch (status) {
      case "good":
        return <div className={`${commonClasses} bg-secondary/20 text-secondary`}>{icon}</div>;
      case "warning":
        return <div className={`${commonClasses} bg-warning/20 text-warning`}>{icon}</div>;
      case "error":
        return <div className={`${commonClasses} bg-destructive/20 text-destructive`}>{icon}</div>;
      default:
        return <div className={`${commonClasses} bg-neutral-100 text-neutral-500`}>{icon}</div>;
    }
  };

  // Calculate the overall technical score
  const getTechnicalScore = () => {
    let score = 0;
    let count = 0;
    
    // Robots tag
    if (robots.status === "good" || robots.status === "not-required") {
      score += 100;
    } else if (robots.status === "warning") {
      score += 50;
    }
    count++;
    
    // Charset
    if (charset.status === "good") {
      score += 100;
    } else if (charset.status === "warning") {
      score += 50;
    }
    count++;
    
    // Language
    if (language.status === "good") {
      score += 100;
    } else if (language.status === "warning") {
      score += 50;
    }
    count++;
    
    return Math.round(score / count);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div 
        className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200 flex justify-between items-center cursor-pointer hover:bg-neutral-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 text-primary">
            <span className="text-sm font-semibold">{getTechnicalScore()}</span>
          </div>
          <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">Technical SEO Tags</h3>
        </div>
        {expanded ? <ChevronUp className="h-5 w-5 text-neutral-500" /> : <ChevronDown className="h-5 w-5 text-neutral-500" />}
      </div>
      
      {expanded && (
        <div className="p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 md:gap-5">
            {/* robots */}
            <div className={`border rounded-lg p-3 sm:p-4 ${getCardClass(robots.status)}`}>
              <div className="flex items-start gap-3">
                {getStatusIcon("robots", robots.status)}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm sm:text-base">Robots Tag</h4>
                    <span className={`text-xs font-medium px-2 py-0.5 sm:py-1 ${getStatusClass(robots.status)} rounded-full`}>
                      {getStatusLabel(robots.status)}
                    </span>
                  </div>
                  
                  <div className="mt-2">
                    {robots.content ? (
                      <div className="bg-white/50 p-2 rounded code text-xs sm:text-sm overflow-auto border border-neutral-200">
                        &lt;meta name="robots" content="{robots.content}"&gt;
                      </div>
                    ) : (
                      <div className="text-xs sm:text-sm text-neutral-600">
                        {robots.status === "error" 
                          ? "No robots tag found. Consider adding one to control search engine crawling."
                          : "No robots tag found. This is generally acceptable as the default behavior is to allow indexing."}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* hreflang */}
            <div className="border border-neutral-200 bg-neutral-50 rounded-lg p-3 sm:p-4">
              <div className="flex items-start gap-3">
                {getStatusIcon("hreflang", "not-required")}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm sm:text-base">Hreflang Tags</h4>
                    <span className="text-xs font-medium px-2 py-0.5 sm:py-1 bg-neutral-100 text-neutral-500 rounded-full">
                      Not Required
                    </span>
                  </div>
                  
                  <div className="mt-2 text-xs sm:text-sm text-neutral-600">
                    <p>No hreflang tags found. These tags are only needed for sites with international or multilingual versions.</p>
                    <div className="mt-2 text-xs bg-neutral-100 p-2 rounded border border-neutral-200">
                      <span className="font-medium text-neutral-700">Example:</span> &lt;link rel="alternate" hreflang="es" href="https://example.com/es/" /&gt;
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* charset */}
            <div className={`border rounded-lg p-3 sm:p-4 ${getCardClass(charset.status)}`}>
              <div className="flex items-start gap-3">
                {getStatusIcon("charset", charset.status)}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm sm:text-base">Character Set</h4>
                    <span className={`text-xs font-medium px-2 py-0.5 sm:py-1 ${getStatusClass(charset.status)} rounded-full`}>
                      {getStatusLabel(charset.status)}
                    </span>
                  </div>
                  
                  <div className="mt-2">
                    {charset.content ? (
                      <div className="bg-white/50 p-2 rounded code text-xs sm:text-sm overflow-auto border border-neutral-200">
                        &lt;meta charset="{charset.content}"&gt;
                      </div>
                    ) : (
                      <div className="flex items-center bg-white/50 p-2 rounded text-xs sm:text-sm text-neutral-600 italic border border-dashed border-destructive/50">
                        <div className="mr-2 text-destructive">✖</div>
                        No charset meta tag found
                      </div>
                    )}
                    {charset.status !== "good" && (
                      <div className="mt-2 text-xs bg-neutral-100 p-2 rounded border border-neutral-200">
                        <span className="font-medium text-neutral-700">Tip:</span> Defining charset (usually UTF-8) helps browsers display text correctly.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* language */}
            <div className={`border rounded-lg p-3 sm:p-4 ${getCardClass(language.status)}`}>
              <div className="flex items-start gap-3">
                {getStatusIcon("language", language.status)}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm sm:text-base">HTML Language</h4>
                    <span className={`text-xs font-medium px-2 py-0.5 sm:py-1 ${getStatusClass(language.status)} rounded-full`}>
                      {getStatusLabel(language.status)}
                    </span>
                  </div>
                  
                  <div className="mt-2">
                    {language.content ? (
                      <div className="bg-white/50 p-2 rounded code text-xs sm:text-sm overflow-auto border border-neutral-200">
                        &lt;html lang="{language.content}"&gt;
                      </div>
                    ) : (
                      <div className="flex items-center bg-white/50 p-2 rounded text-xs sm:text-sm text-neutral-600 italic border border-dashed border-destructive/50">
                        <div className="mr-2 text-destructive">✖</div>
                        No HTML language attribute found
                      </div>
                    )}
                    {language.status !== "good" && (
                      <div className="mt-2 text-xs bg-neutral-100 p-2 rounded border border-neutral-200">
                        <span className="font-medium text-neutral-700">Tip:</span> The lang attribute helps screen readers and search engines understand your content's language.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
