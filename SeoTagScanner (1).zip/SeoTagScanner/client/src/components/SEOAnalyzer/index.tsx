import React, { useState } from "react";
import { Search, ExternalLink, CheckCircle, Tag, Share2, FileCode } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { SEOAnalysisResult } from "@/lib/types";
import AnalysisResults from "./AnalysisResults";
import LoadingState from "./LoadingState";
import ErrorState from "./ErrorState";

export default function SEOAnalyzer() {
  const [url, setUrl] = useState("");
  const [submittedUrl, setSubmittedUrl] = useState("");
  const { toast } = useToast();

  const {
    data: analysisResult,
    isLoading,
    error,
    isFetching,
    refetch,
  } = useQuery<SEOAnalysisResult>({
    queryKey: [`/api/analyze?url=${encodeURIComponent(submittedUrl)}`, submittedUrl],
    enabled: !!submittedUrl,
  });

  const normalizeUrl = (inputUrl: string): string => {
    // Remove any leading/trailing whitespace
    let cleanUrl = inputUrl.trim();
    
    // Add https:// if protocol is missing
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = `https://${cleanUrl}`;
    }
    
    return cleanUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) {
      toast({
        title: "URL Required",
        description: "Please enter a valid URL to analyze",
        variant: "destructive",
      });
      return;
    }

    try {
      // Normalize and validate URL format
      const normalizedUrl = normalizeUrl(url);
      new URL(normalizedUrl);
      setSubmittedUrl(normalizedUrl);
    } catch (error) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL with correct format",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setSubmittedUrl("");
  };

  const showResults = submittedUrl && !isLoading && !isFetching && !error;
  const showError = submittedUrl && !isLoading && !isFetching && error;
  const showLoading = submittedUrl && (isLoading || isFetching);
  const showWelcome = !submittedUrl && !isLoading && !isFetching && !error;

  // Sample URLs for quick testing
  const sampleUrls = [
    "google.com",
    "twitter.com",
    "github.com",
    "replit.com"
  ];

  return (
    <>
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 sm:py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center sm:mb-0">
            <svg
              className="w-6 h-6 sm:w-7 sm:h-7 text-primary mr-2.5 flex-shrink-0"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M3 3v18h18" />
              <path d="m3 15 5-5 5 5 8-8" />
            </svg>
            <h1 className="text-xl sm:text-2xl font-semibold text-neutral-800">
              SEO Tag Analyzer
            </h1>
          </div>

          <div className="w-full sm:w-[480px]">
            <form onSubmit={handleSubmit} className="flex w-full">
              <div className="relative flex-grow">
                <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Enter website URL"
                  className="w-full pl-11 pr-4 py-2.5 rounded-l-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-base"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  required
                />
              </div>
              <button
                type="submit"
                disabled={isLoading || isFetching}
                className="bg-primary hover:bg-primary/90 text-white px-6 py-2.5 rounded-r-lg font-medium transition flex items-center text-base whitespace-nowrap"
              >
                {(isLoading || isFetching) ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <span>Analyze</span>
                )}
              </button>
            </form>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-4 py-4 sm:py-6 flex-grow">
        {showLoading && <LoadingState />}
        {showError && <ErrorState onReset={resetForm} />}
        {showResults && analysisResult && (
          <AnalysisResults result={analysisResult} />
        )}
        
        {/* Welcome Screen with SEO Information */}
        {showWelcome && (
          <div className="animate-fadeIn">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-xl p-4 sm:p-6 mb-4 sm:mb-6 border border-primary/10">
              <div className="max-w-3xl mx-auto text-center">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-neutral-800 mb-2 sm:mb-3">Analyze Your Website's SEO Meta Tags</h1>
                <p className="text-neutral-600 text-sm sm:text-base mb-4 sm:mb-6">Understand how search engines and social media platforms see your website, and get recommendations to improve your visibility.</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {sampleUrls.map((sampleUrl) => (
                    <button
                      key={sampleUrl}
                      onClick={() => {
                        setUrl(sampleUrl);
                        setSubmittedUrl(normalizeUrl(sampleUrl));
                      }}
                      className="bg-white hover:bg-neutral-50 text-neutral-700 px-2 sm:px-3 py-1.5 sm:py-2 rounded border border-neutral-200 text-xs sm:text-sm transition flex items-center gap-1"
                    >
                      <ExternalLink className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
                      <span>Try {sampleUrl}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* What is SEO? - Visual explanation */}
            <div className="bg-white rounded-xl shadow-sm mb-4 sm:mb-6 overflow-hidden">
              <div className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200">
                <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">What is SEO?</h3>
              </div>
              <div className="p-3 sm:p-4 md:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
                  <div className="bg-neutral-50 rounded-lg p-3 sm:p-4 border border-neutral-100">
                    <div className="flex justify-center mb-2 sm:mb-3">
                      <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Tag className="h-5 w-5 sm:h-6 sm:w-6" />
                      </div>
                    </div>
                    <h4 className="font-medium text-center mb-1 sm:mb-2 text-sm sm:text-base">Meta Tags</h4>
                    <p className="text-neutral-600 text-xs sm:text-sm text-center">Hidden HTML elements that provide information about your webpage to search engines and social platforms.</p>
                  </div>
                  
                  <div className="bg-neutral-50 rounded-lg p-3 sm:p-4 border border-neutral-100">
                    <div className="flex justify-center mb-2 sm:mb-3">
                      <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
                        <Search className="h-5 w-5 sm:h-6 sm:w-6" />
                      </div>
                    </div>
                    <h4 className="font-medium text-center mb-1 sm:mb-2 text-sm sm:text-base">Search Visibility</h4>
                    <p className="text-neutral-600 text-xs sm:text-sm text-center">Proper meta tags help search engines understand your content and display it correctly in search results.</p>
                  </div>
                  
                  <div className="bg-neutral-50 rounded-lg p-3 sm:p-4 border border-neutral-100">
                    <div className="flex justify-center mb-2 sm:mb-3">
                      <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Share2 className="h-5 w-5 sm:h-6 sm:w-6" />
                      </div>
                    </div>
                    <h4 className="font-medium text-center mb-1 sm:mb-2 text-sm sm:text-base">Social Sharing</h4>
                    <p className="text-neutral-600 text-xs sm:text-sm text-center">Social media tags control how your content appears when shared on platforms like Facebook and Twitter.</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* What We Analyze */}
            <div className="bg-white rounded-xl shadow-sm mb-4 sm:mb-6 overflow-hidden">
              <div className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200">
                <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">What We Analyze</h3>
              </div>
              <div className="p-3 sm:p-4 md:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                  <div className="flex">
                    <div className="mr-2 sm:mr-3 text-secondary flex-shrink-0">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-800 mb-0.5 sm:mb-1 text-sm sm:text-base">Core Meta Tags</h4>
                      <p className="text-neutral-600 text-xs sm:text-sm">Title, description, viewport, and canonical URL tags.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-2 sm:mr-3 text-secondary flex-shrink-0">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-800 mb-0.5 sm:mb-1 text-sm sm:text-base">Social Media Tags</h4>
                      <p className="text-neutral-600 text-xs sm:text-sm">Open Graph and Twitter Card tags for social media sharing.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-2 sm:mr-3 text-secondary flex-shrink-0">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-800 mb-0.5 sm:mb-1 text-sm sm:text-base">Technical Tags</h4>
                      <p className="text-neutral-600 text-xs sm:text-sm">Robots, charset, and language tags for technical optimization.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-2 sm:mr-3 text-secondary flex-shrink-0">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-800 mb-0.5 sm:mb-1 text-sm sm:text-base">Visual Previews</h4>
                      <p className="text-neutral-600 text-xs sm:text-sm">See how your website appears in search results and social media.</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-neutral-100">
                  <div className="flex">
                    <div className="mr-2 sm:mr-3 mt-0.5 text-primary flex-shrink-0">
                      <FileCode className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-800 mb-0.5 sm:mb-1 text-sm sm:text-base">Get Actionable Recommendations</h4>
                      <p className="text-neutral-600 text-xs sm:text-sm">Receive specific suggestions to improve your website's SEO and social media presence based on our analysis.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* How to Use */}
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200">
                <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">How to Use This Tool</h3>
              </div>
              <div className="p-3 sm:p-4 md:p-6">
                <ol className="space-y-2 sm:space-y-3">
                  <li className="flex">
                    <div className="flex-shrink-0 flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mr-2 sm:mr-3 mt-0.5">1</div>
                    <p className="text-neutral-600 text-xs sm:text-sm">Enter a website URL in the search box at the top of the page and click "Analyze".</p>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0 flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mr-2 sm:mr-3 mt-0.5">2</div>
                    <p className="text-neutral-600 text-xs sm:text-sm">Review the summary scores for a quick overview of your SEO performance.</p>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0 flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mr-2 sm:mr-3 mt-0.5">3</div>
                    <p className="text-neutral-600 text-xs sm:text-sm">Explore detailed analyses of your core meta tags, social media tags, and technical SEO.</p>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0 flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mr-2 sm:mr-3 mt-0.5">4</div>
                    <p className="text-neutral-600 text-xs sm:text-sm">Check the visual previews to see how your website appears in search results and social media.</p>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0 flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-primary/10 text-primary text-xs sm:text-sm font-medium mr-2 sm:mr-3 mt-0.5">5</div>
                    <p className="text-neutral-600 text-xs sm:text-sm">Follow our recommendations to improve your website's SEO and social media presence.</p>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-neutral-200 py-3 sm:py-4 md:py-6">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="text-center text-neutral-500 text-xs sm:text-sm">
            <p className="text-xs sm:text-sm">
              SEO Tag Analyzer © {new Date().getFullYear()} - Analyze and
              improve your website's SEO metadata
            </p>
            <p className="mt-1 sm:mt-2 text-xs sm:text-sm">
              This tool checks meta tags only. A comprehensive SEO strategy
              involves many other factors.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
