import React, { useState } from "react";
import { AlertTriangle, HelpCircle, ChevronDown, ChevronUp, AlertCircle, CheckCircle } from "lucide-react";
import { Recommendation } from "@/lib/types";

interface RecommendationsProps {
  recommendations: Recommendation[];
}

export default function Recommendations({ recommendations }: RecommendationsProps) {
  const [expanded, setExpanded] = useState(true);
  
  // Group recommendations by priority
  const highPriority = recommendations.filter(rec => rec.priority === "high");
  const mediumPriority = recommendations.filter(rec => rec.priority === "medium");
  const lowPriority = recommendations.filter(rec => rec.priority === "low");
  
  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high": return "Critical";
      case "medium": return "Important";
      case "low": return "Minor";
      default: return "";
    }
  };
  
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-destructive/10 text-destructive border-destructive/20";
      case "medium": return "bg-warning/10 text-warning border-warning/20";
      case "low": return "bg-neutral-100 text-neutral-600 border-neutral-200";
      default: return "bg-neutral-100 text-neutral-600 border-neutral-200";
    }
  };
  
  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high": return <AlertCircle className="h-5 w-5" />;
      case "medium": return <AlertTriangle className="h-5 w-5" />;
      case "low": return <HelpCircle className="h-5 w-5" />;
      default: return <HelpCircle className="h-5 w-5" />;
    }
  };

  if (recommendations.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="px-3 py-2 border-b border-neutral-200 flex justify-between items-center">
          <div className="flex items-center gap-1.5">
            <CheckCircle className="text-secondary h-4 w-4" />
            <h3 className="font-semibold text-neutral-800 text-sm">Improvement Recommendations</h3>
          </div>
        </div>
        <div className="p-3">
          <div className="bg-secondary/5 border border-secondary/20 rounded-lg p-2 text-center">
            <div className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-secondary/20 text-secondary mb-1">
              <CheckCircle className="h-4 w-4" />
            </div>
            <h4 className="font-medium text-neutral-800 text-xs mb-0.5">No Improvements Needed!</h4>
            <p className="text-xs text-neutral-600">Your SEO tags follow best practices.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden w-full">
      <div 
        className="px-3 py-2 border-b border-neutral-200 flex justify-between items-center cursor-pointer hover:bg-neutral-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-1.5">
          <div className="flex items-center justify-center h-5 w-5 rounded-full bg-warning/10 text-warning">
            <span className="text-xs font-semibold">{recommendations.length}</span>
          </div>
          <h3 className="font-semibold text-neutral-800 text-sm">Improvement Recommendations</h3>
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-neutral-500" /> : <ChevronDown className="h-4 w-4 text-neutral-500" />}
      </div>
      
      {expanded && (
        <div className="p-3">
          {/* Priority stats */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            {highPriority.length > 0 && (
              <div className="bg-destructive/5 border border-destructive/20 rounded-lg p-2 text-center">
                <div className="text-base font-bold text-destructive mb-0.5">{highPriority.length}</div>
                <div className="text-[10px] text-neutral-700">Critical</div>
              </div>
            )}
            {mediumPriority.length > 0 && (
              <div className="bg-warning/5 border border-warning/20 rounded-lg p-2 text-center">
                <div className="text-base font-bold text-warning mb-0.5">{mediumPriority.length}</div>
                <div className="text-[10px] text-neutral-700">Important</div>
              </div>
            )}
            {lowPriority.length > 0 && (
              <div className="bg-neutral-100 border border-neutral-200 rounded-lg p-2 text-center">
                <div className="text-base font-bold text-neutral-700 mb-0.5">{lowPriority.length}</div>
                <div className="text-[10px] text-neutral-700">Minor</div>
              </div>
            )}
          </div>
          
          {/* Recommendations list */}
          <div className="space-y-2">
            {recommendations.map((rec, index) => (
              <div 
                className={`p-2 border rounded-lg ${getPriorityColor(rec.priority)}`} 
                key={index}
              >
                <div className="flex items-start gap-2">
                  <div className={`rounded-full p-1 flex-shrink-0 ${rec.priority === "high" ? "bg-destructive/10" : rec.priority === "medium" ? "bg-warning/10" : "bg-neutral-100"}`}>
                    {getPriorityIcon(rec.priority)}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start gap-1">
                      <h4 className="font-medium text-neutral-800 text-xs">{rec.title}</h4>
                      <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full flex-shrink-0 ${rec.priority === "high" ? "bg-destructive/10 text-destructive" : rec.priority === "medium" ? "bg-warning/10 text-warning" : "bg-neutral-100 text-neutral-600"}`}>
                        {getPriorityLabel(rec.priority)}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 mt-0.5">{rec.description}</p>
                    {rec.example && (
                      <div className="mt-1 code bg-white/70 p-1.5 rounded text-[10px] overflow-auto border border-neutral-200">
                        {rec.example}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
