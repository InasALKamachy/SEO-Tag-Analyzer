import React from "react";
import { Search, Tag, FileCheck, Share2, CheckCircle2 } from "lucide-react";

export default function LoadingState() {
  return (
    <div className="flex flex-col items-center justify-center py-10 sm:py-16">
      {/* Animated progress bar */}
      <div className="w-full max-w-md mb-8 px-4">
        <div className="h-2 w-full bg-neutral-100 rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full animate-progress-indeterminate"></div>
        </div>
      </div>
      
      {/* Loading animation */}
      <div className="relative w-32 h-32 mb-6">
        {/* Center circle */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-white shadow-md flex items-center justify-center z-10">
            <Search className="h-8 w-8 text-primary animate-pulse" />
          </div>
        </div>
        
        {/* Orbiting icons */}
        <div className="absolute inset-0">
          <div className="w-full h-full animate-spin-slow">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Tag className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute inset-0">
          <div className="w-full h-full animate-spin-slow" style={{ animationDelay: "0.5s" }}>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <FileCheck className="h-5 w-5 text-blue-600" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute inset-0">
          <div className="w-full h-full animate-spin-slow" style={{ animationDelay: "1s" }}>
            <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center">
                <Share2 className="h-5 w-5 text-amber-600" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute inset-0">
          <div className="w-full h-full animate-spin-slow" style={{ animationDelay: "1.5s" }}>
            <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Status text with typing animation */}
      <div className="text-center">
        <h3 className="text-lg sm:text-xl font-semibold text-neutral-800 mb-2">Analyzing Website</h3>
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-1.5 text-sm sm:text-base text-neutral-600 font-medium mb-1">
            <span className="animate-pulse">Checking meta tags</span>
            <span className="inline-flex">
              <span className="animate-[pulse_1s_ease-in-out_infinite]">.</span>
              <span className="animate-[pulse_1s_ease-in-out_0.2s_infinite]">.</span>
              <span className="animate-[pulse_1s_ease-in-out_0.4s_infinite]">.</span>
            </span>
          </div>
          <p className="text-xs sm:text-sm text-neutral-500">This may take a few moments</p>
        </div>
      </div>
      
      {/* SEO Tips while waiting */}
      <div className="mt-10 max-w-md bg-neutral-50 rounded-lg p-4 border border-neutral-200">
        <h4 className="text-sm font-medium text-neutral-700 mb-2">Did you know?</h4>
        <p className="text-xs text-neutral-600">
          Websites with properly implemented meta tags typically perform better in search results and 
          generate more engaging previews when shared on social media platforms.
        </p>
      </div>
    </div>
  );
}
