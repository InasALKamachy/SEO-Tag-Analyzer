import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { KeyRound, AlertTriangle, Check, Info } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface KeywordAnalysisProps {
  url: string;
  title: {
    content: string;
  };
  description: {
    content: string | null;
  };
  contentAnalysis?: {
    contentLength?: number;
    keywordDensity?: {
      [keyword: string]: number;
    };
  };
}

export default function KeywordAnalysis({ url, title, description, contentAnalysis }: KeywordAnalysisProps) {
  // Extract potential focus keywords from title and description
  const extractKeywords = (text: string): string[] => {
    if (!text) return [];
    
    // Remove common stop words
    const stopWords = ["a", "an", "the", "and", "or", "but", "is", "are", "on", "in", "to", "for", "with", "by", "at", "of", "this", "that"];
    
    // Extract words, remove punctuation, convert to lowercase
    const words = text.toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(word => word.length > 3 && !stopWords.includes(word));
    
    // Count word frequency
    const wordCount: { [key: string]: number } = {};
    words.forEach(word => {
      wordCount[word] = (wordCount[word] || 0) + 1;
    });
    
    // Sort by frequency
    return Object.keys(wordCount)
      .sort((a, b) => wordCount[b] - wordCount[a])
      .slice(0, 5); // Get top 5 keywords
  };
  
  const titleKeywords = title.content ? extractKeywords(title.content) : [];
  const descKeywords = description.content ? extractKeywords(description.content) : [];
  
  // Combine and deduplicate keywords
  const combinedKeywords = [...titleKeywords, ...descKeywords];
  const uniqueKeywords: string[] = [];
  
  // Manual deduplication
  combinedKeywords.forEach(keyword => {
    if (!uniqueKeywords.includes(keyword)) {
      uniqueKeywords.push(keyword);
    }
  });
  
  const allKeywords = uniqueKeywords.slice(0, 5);
  
  // Calculate keyword presence metrics
  const keywordMetrics = allKeywords.map(keyword => {
    const inTitle = title.content?.toLowerCase().includes(keyword.toLowerCase()) || false;
    const inDescription = description.content?.toLowerCase().includes(keyword.toLowerCase()) || false;
    const inUrl = url.toLowerCase().includes(keyword.toLowerCase());
    const density = contentAnalysis?.keywordDensity?.[keyword] || 0;
    
    // Calculate a rough optimization score for this keyword
    let score = 0;
    if (inTitle) score += 33;
    if (inDescription) score += 33;
    if (inUrl) score += 24;
    if (density > 0.5 && density < 2.5) score += 10;
    
    let status: "good" | "warning" | "needs-improvement" = "needs-improvement";
    if (score >= 80) status = "good";
    else if (score >= 40) status = "warning";
    
    return {
      keyword,
      inTitle,
      inDescription,
      inUrl,
      density,
      score,
      status
    };
  });
  
  return (
    <Card className="mt-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-transparent to-blue-100 dark:to-blue-950 rounded-bl-full opacity-50"></div>
      
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <KeyRound className="h-5 w-5" />
          Keyword Analysis
          <Badge className="bg-blue-500 text-white ml-2">Advanced</Badge>
        </CardTitle>
        <CardDescription>
          Analysis of potential focus keywords and their optimization across your page
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-6">
          {/* Potential focus keywords */}
          <div>
            <h3 className="text-lg font-medium mb-3">Potential Focus Keywords</h3>
            
            {allKeywords.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Keyword</TableHead>
                      <TableHead>In Title</TableHead>
                      <TableHead>In Description</TableHead>
                      <TableHead>In URL</TableHead>
                      <TableHead>Density</TableHead>
                      <TableHead>Optimization</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {keywordMetrics.map((metric, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{metric.keyword}</TableCell>
                        <TableCell>
                          {metric.inTitle ? 
                            <Check className="h-4 w-4 text-green-500" /> : 
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                          }
                        </TableCell>
                        <TableCell>
                          {metric.inDescription ? 
                            <Check className="h-4 w-4 text-green-500" /> : 
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                          }
                        </TableCell>
                        <TableCell>
                          {metric.inUrl ? 
                            <Check className="h-4 w-4 text-green-500" /> : 
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                          }
                        </TableCell>
                        <TableCell>
                          {metric.density ? 
                            `${metric.density.toFixed(1)}%` : 
                            "N/A"
                          }
                        </TableCell>
                        <TableCell>
                          <div className="w-full flex items-center gap-2">
                            <Progress value={metric.score} className="h-2 flex-grow" />
                            <span className="text-xs font-medium">{metric.score}%</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-md text-amber-800 dark:text-amber-300">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium">No clear keywords detected</p>
                    <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                      We couldn't identify clear focus keywords from your title and description.
                      Consider updating your content to include specific keywords relevant to your page's topic.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <Separator />
          
          {/* Recommendations */}
          <div>
            <h3 className="text-lg font-medium mb-3">Keyword Optimization Tips</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="font-medium">Include your main keyword in important elements</p>
                  <p className="text-sm text-muted-foreground">
                    Your primary keyword should appear in your title, meta description, URL, H1 heading, and naturally throughout your content.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="font-medium">Maintain natural keyword density</p>
                  <p className="text-sm text-muted-foreground">
                    Aim for a keyword density between 0.5% and 2.5%. Higher may appear as keyword stuffing, which can harm rankings.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <Info className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="font-medium">Use variations and related terms</p>
                  <p className="text-sm text-muted-foreground">
                    Modern search engines understand semantic relationships. Include synonyms and related terms to support your main keywords.
                  </p>
                </div>
              </li>
            </ul>
          </div>
          
          <Separator />
          
          {/* Educational Section */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-indigo-950 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">Why Keyword Optimization Matters</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Proper keyword usage helps search engines understand what your content is about and match it to relevant searches:
            </p>
            <ul className="text-sm space-y-2">
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Strategic placement</strong> of keywords in titles, headings, and early in content signals importance to search engines</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Natural keyword distribution</strong> throughout content helps establish topical relevance</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span><strong>Related terms and synonyms</strong> help search engines understand context and match to more searches</span>
              </li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}