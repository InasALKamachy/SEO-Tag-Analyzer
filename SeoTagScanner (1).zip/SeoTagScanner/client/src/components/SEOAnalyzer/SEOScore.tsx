import React from "react";
import { Download, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

interface SEOScoreProps {
  score: number;
  tagCount: number;
  websiteUrl: string;
}

export default function SEOScore({ score, tagCount, websiteUrl }: SEOScoreProps) {
  const getScoreRating = (score: number) => {
    if (score >= 90) return "Excellent";
    if (score >= 70) return "Good";
    if (score >= 50) return "Fair";
    return "Poor";
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-secondary";
    if (score >= 70) return "text-primary";
    if (score >= 50) return "text-warning";
    return "text-destructive";
  };

  const getScoreBorderColor = (score: number) => {
    if (score >= 90) return "border-secondary";
    if (score >= 70) return "border-primary";
    if (score >= 50) return "border-warning";
    return "border-destructive";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 90) return "bg-secondary/5 from-secondary/20 to-secondary/5";
    if (score >= 70) return "bg-primary/5 from-primary/20 to-primary/5";
    if (score >= 50) return "bg-warning/5 from-warning/20 to-warning/5";
    return "bg-destructive/5 from-destructive/20 to-destructive/5";
  };

  const getScoreIcon = (score: number) => {
    if (score >= 90) return <CheckCircle className="h-5 w-5 text-secondary" />;
    if (score >= 70) return <CheckCircle className="h-5 w-5 text-primary" />;
    if (score >= 50) return <AlertTriangle className="h-5 w-5 text-warning" />;
    return <XCircle className="h-5 w-5 text-destructive" />;
  };

  // Calculate arc path for the gauge
  const radius = 36;
  const strokeWidth = 8;
  const normalizedRadius = radius - strokeWidth / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  // We're not implementing actual download functionality as it wasn't in the core requirements
  const handleDownload = () => {
    alert("Download functionality would be implemented here");
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-3 mb-3 w-full">
      <div className="flex flex-col sm:flex-row sm:items-center">
        <div className="flex-grow mb-2 sm:mb-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-lg font-semibold text-neutral-800">SEO Analysis Results</h2>
            <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-neutral-100 text-neutral-600">
              {tagCount} tags analyzed
            </span>
          </div>
          <p className="text-neutral-600 mt-1 text-xs break-all">{websiteUrl}</p>
        </div>
        
        <div className="flex items-center">
          <div className="mr-2">
            <div className="flex items-center gap-2">
              {/* Score Gauge */}
              <div className="relative">
                <div className="w-16 h-16 flex items-center justify-center relative">
                  {/* SVG for circular gauge */}
                  <svg 
                    className="w-full h-full transform -rotate-90"
                    viewBox="0 0 100 100"
                  >
                    {/* Light gray background track */}
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      stroke="#F5F5F5"
                      strokeWidth="10"
                    />
                    
                    {/* Colored progress arc */}
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      stroke={score >= 90 ? "#4ADE80" : 
                             score >= 70 ? "#3b82f6" : 
                             score >= 50 ? "#FB923C" : 
                             "#E11D48"}
                      strokeWidth="10"
                      strokeDasharray={`${2 * Math.PI * 42 * (score / 100)} ${2 * Math.PI * 42}`}
                      strokeLinecap="round"
                    />
                  </svg>
                  
                  {/* Text in the center - just the number */}
                  <div className="absolute inset-0 flex items-center justify-center text-center">
                    <span className="text-neutral-900 text-2xl font-bold">{score}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-bold text-neutral-800 mb-0.5">Overall SEO Score</h3>
                <div className="flex items-center gap-1">
                  {getScoreIcon(score)}
                  <p className="font-semibold text-neutral-800 text-xs">{getScoreRating(score)}</p>
                </div>
                <div className="text-xs text-neutral-500">
                  {score >= 90 ? (
                    "SEO optimized!"
                  ) : score >= 70 ? (
                    "Room for improvement"
                  ) : score >= 50 ? (
                    "Issues need attention"
                  ) : (
                    "Critical issues"
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* SEO Score Legend - helps beginners understand scores */}
      <div className="mt-2 pt-2 border-t border-neutral-100">
        <div className="grid grid-cols-4 gap-1">
          <div className="flex flex-col items-center">
            <div className="h-1.5 w-full bg-destructive/20 rounded-full mb-0.5"></div>
            <span className="text-[10px] text-neutral-500">0-49</span>
            <span className="text-[10px] text-neutral-500">Poor</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="h-1.5 w-full bg-warning/20 rounded-full mb-0.5"></div>
            <span className="text-[10px] text-neutral-500">50-69</span>
            <span className="text-[10px] text-neutral-500">Fair</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="h-1.5 w-full bg-primary/20 rounded-full mb-0.5"></div>
            <span className="text-[10px] text-neutral-500">70-89</span>
            <span className="text-[10px] text-neutral-500">Good</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="h-1.5 w-full bg-secondary/20 rounded-full mb-0.5"></div>
            <span className="text-[10px] text-neutral-500">90-100</span>
            <span className="text-[10px] text-neutral-500">Excellent</span>
          </div>
        </div>
      </div>
    </div>
  );
}
