import React, { useState } from "react";
import { CheckCircle, AlertTriangle, XCircle, ChevronDown, ChevronUp } from "lucide-react";

interface CoreMetaTagsProps {
  title: {
    content: string;
    length: number;
    status: "good" | "warning" | "error";
    message?: string;
  };
  description: {
    content: string | null;
    length: number;
    status: "good" | "warning" | "error";
    message?: string;
  };
  viewport: {
    content: string | null;
    status: "good" | "warning" | "error";
    message?: string;
  };
  canonical: {
    content: string | null;
    status: "good" | "warning" | "error";
    message?: string;
  };
}

export default function CoreMetaTags({ title, description, viewport, canonical }: CoreMetaTagsProps) {
  const [expanded, setExpanded] = useState(true);

  const statusIcons = {
    good: <CheckCircle className="text-secondary mr-2 h-4 w-4 sm:h-5 sm:w-5" />,
    warning: <AlertTriangle className="text-warning mr-2 h-4 w-4 sm:h-5 sm:w-5" />,
    error: <XCircle className="text-destructive mr-2 h-4 w-4 sm:h-5 sm:w-5" />,
  };

  const statusLabels = {
    good: "Good",
    warning: "Needs Improvement",
    error: "Missing",
  };

  const statusClasses = {
    good: "bg-secondary/10 text-secondary",
    warning: "bg-warning/10 text-warning",
    error: "bg-destructive/10 text-destructive",
  };

  // Calculate percentage for progress bar
  const getPercentage = (length: number, min: number, max: number) => {
    if (length < min) return (length / min) * 50; // 0-50% if below minimum
    if (length > max) return 50 + 50 * (1 - (length - max) / max); // 50-100% if above maximum, decreasing
    return 50 + (length - min) / (max - min) * 50; // 50-100% if in ideal range
  };

  const titlePercentage = getPercentage(title.length, 30, 60);
  const descPercentage = getPercentage(description.length || 0, 120, 160);

  const getProgressColor = (status: string) => {
    switch(status) {
      case "good": return "bg-secondary";
      case "warning": return "bg-warning";
      case "error": return "bg-destructive";
      default: return "bg-neutral-300";
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div 
        className="px-4 sm:px-6 py-3 sm:py-4 border-b border-neutral-200 flex justify-between items-center cursor-pointer hover:bg-neutral-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2">
          <div className="flex -space-x-1 overflow-hidden">
            {title.status === "good" && <div className="inline-block h-5 w-5 rounded-full ring-2 ring-white bg-secondary flex items-center justify-center text-white text-xs font-bold">T</div>}
            {description.status === "good" && <div className="inline-block h-5 w-5 rounded-full ring-2 ring-white bg-secondary flex items-center justify-center text-white text-xs font-bold">D</div>}
            {viewport.status === "good" && <div className="inline-block h-5 w-5 rounded-full ring-2 ring-white bg-secondary flex items-center justify-center text-white text-xs font-bold">V</div>}
            {canonical.status === "good" && <div className="inline-block h-5 w-5 rounded-full ring-2 ring-white bg-secondary flex items-center justify-center text-white text-xs font-bold">C</div>}
          </div>
          <h3 className="font-semibold text-neutral-800 text-base sm:text-lg">Core Meta Tags</h3>
        </div>
        {expanded ? <ChevronUp className="h-5 w-5 text-neutral-500" /> : <ChevronDown className="h-5 w-5 text-neutral-500" />}
      </div>
      
      {expanded && (
        <div className="p-4 sm:p-6">
          {/* Title Tag */}
          <div className="mb-4 sm:mb-6">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center">
                {statusIcons[title.status]}
                <h4 className="font-medium text-sm sm:text-base">Title Tag</h4>
              </div>
              <span className={`text-xs font-medium px-2 py-1 ${statusClasses[title.status]} rounded-full`}>
                {statusLabels[title.status]}
              </span>
            </div>
            <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg code text-xs sm:text-sm overflow-auto">
              &lt;title&gt;{title.content}&lt;/title&gt;
            </div>
            <div className="mt-2">
              <div className="flex justify-between items-center mb-1 text-xs text-neutral-500">
                <span>0</span>
                <span className="font-medium">Ideal: 50-60 characters</span>
                <span>100+</span>
              </div>
              <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getProgressColor(title.status)}`} 
                  style={{ width: `${Math.min(100, titlePercentage)}%` }}
                ></div>
              </div>
              <p className="mt-1 text-xs sm:text-sm text-neutral-600">
                <span className="font-medium">Current Length:</span> {title.length} characters
              </p>
            </div>
          </div>
          
          {/* Meta Description */}
          <div className="mb-4 sm:mb-6">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center">
                {statusIcons[description.status]}
                <h4 className="font-medium text-sm sm:text-base">Meta Description</h4>
              </div>
              <span className={`text-xs font-medium px-2 py-1 ${statusClasses[description.status]} rounded-full`}>
                {statusLabels[description.status]}
              </span>
            </div>
            {description.content ? (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg code text-xs sm:text-sm overflow-auto">
                &lt;meta name="description" content="{description.content}"&gt;
              </div>
            ) : (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg border border-dashed border-destructive/50 text-xs sm:text-sm text-neutral-500 italic">
                No meta description found
              </div>
            )}
            <div className="mt-2">
              <div className="flex justify-between items-center mb-1 text-xs text-neutral-500">
                <span>0</span>
                <span className="font-medium">Ideal: 150-160 characters</span>
                <span>200+</span>
              </div>
              <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${getProgressColor(description.status)}`} 
                  style={{ width: `${Math.min(100, descPercentage)}%` }}
                ></div>
              </div>
              <p className="mt-1 text-xs sm:text-sm text-neutral-600">
                <span className="font-medium">Current Length:</span> {description.length} characters
              </p>
            </div>
          </div>
          
          {/* Meta Viewport */}
          <div className="mb-4 sm:mb-6">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center">
                {statusIcons[viewport.status]}
                <h4 className="font-medium text-sm sm:text-base">Meta Viewport</h4>
              </div>
              <span className={`text-xs font-medium px-2 py-1 ${statusClasses[viewport.status]} rounded-full`}>
                {statusLabels[viewport.status]}
              </span>
            </div>
            {viewport.content ? (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg code text-xs sm:text-sm overflow-auto">
                &lt;meta name="viewport" content="{viewport.content}"&gt;
              </div>
            ) : (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg border border-dashed border-destructive/50 text-xs sm:text-sm text-neutral-500 italic">
                No viewport tag found
              </div>
            )}
            {viewport.status !== "good" && (
              <div className="mt-2 text-xs sm:text-sm text-neutral-600 p-2 bg-warning/5 border border-warning/20 rounded">
                <span className="font-medium">Why it matters:</span> The viewport meta tag is essential for mobile responsiveness.
              </div>
            )}
          </div>
          
          {/* Canonical URL */}
          <div>
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center">
                {statusIcons[canonical.status]}
                <h4 className="font-medium text-sm sm:text-base">Canonical URL</h4>
              </div>
              <span className={`text-xs font-medium px-2 py-1 ${statusClasses[canonical.status]} rounded-full`}>
                {statusLabels[canonical.status]}
              </span>
            </div>
            {canonical.content ? (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg code text-xs sm:text-sm overflow-auto">
                &lt;link rel="canonical" href="{canonical.content}"&gt;
              </div>
            ) : (
              <div className="bg-neutral-50 p-2 sm:p-3 rounded-lg border border-dashed border-destructive/50 text-xs sm:text-sm text-neutral-500 italic">
                No canonical URL tag found
              </div>
            )}
            {canonical.status === "error" && (
              <div className="mt-2 text-xs sm:text-sm text-neutral-600 p-2 bg-destructive/5 border border-destructive/20 rounded">
                <span className="font-medium">Why it matters:</span> Canonical URLs prevent duplicate content issues and help search engines understand which version of a page to index.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
