import React from "react";
import { SEOAnalysisResult } from "@/lib/types";
import CategorySummary from "./CategorySummary";

interface SEOSummaryProps {
  result: SEOAnalysisResult;
}

export default function SEOSummary({ result }: SEOSummaryProps) {
  // Calculate scores for each category
  const getCoreTagsStatus = () => {
    const totalTags = 4; // title, description, viewport, canonical
    let goodCount = 0;
    let score = 0;
    
    // Title tag check
    if (result.title.status === "good") goodCount++;
    score += result.title.status === "good" ? 25 : (result.title.status === "warning" ? 15 : 0);
    
    // Description tag check
    if (result.description.status === "good") goodCount++;
    score += result.description.status === "good" ? 25 : (result.description.status === "warning" ? 15 : 0);
    
    // Viewport tag check
    if (result.viewport.status === "good") goodCount++;
    score += result.viewport.status === "good" ? 25 : (result.viewport.status === "warning" ? 15 : 0);
    
    // Canonical tag check
    if (result.canonical.status === "good") goodCount++;
    score += result.canonical.status === "good" ? 25 : (result.canonical.status === "warning" ? 15 : 0);
    
    let status: "good" | "warning" | "error" = "error";
    if (score >= 75) status = "good";
    else if (score >= 40) status = "warning";
    
    return {
      score,
      status,
      count: {
        total: totalTags,
        good: goodCount
      }
    };
  };
  
  const getSocialTagsStatus = () => {
    const totalTags = 8; // OG (title, description, image, url) + Twitter (card, title, description, image)
    let goodCount = 0;
    let score = 0;
    
    // Check Open Graph tags
    if (result.openGraph.title) { goodCount++; score += 12.5; }
    if (result.openGraph.description) { goodCount++; score += 12.5; }
    if (result.openGraph.image) { goodCount++; score += 12.5; }
    if (result.openGraph.url) { goodCount++; score += 12.5; }
    
    // Check Twitter tags
    if (result.twitter.card) { goodCount++; score += 12.5; }
    if (result.twitter.title) { goodCount++; score += 12.5; }
    if (result.twitter.description) { goodCount++; score += 12.5; }
    if (result.twitter.image) { goodCount++; score += 12.5; }
    
    let status: "good" | "warning" | "error" = "error";
    if (score >= 75) status = "good";
    else if (score >= 40) status = "warning";
    
    return {
      score,
      status,
      count: {
        total: totalTags,
        good: goodCount
      }
    };
  };
  
  const getTechnicalTagsStatus = () => {
    const totalTags = 3; // robots, charset, language
    let goodCount = 0;
    let score = 0;
    
    // Robots tag check
    if (result.robots.status === "good" || result.robots.status === "not-required") {
      goodCount++;
      score += 33;
    } else if (result.robots.status === "warning") {
      score += 20;
    }
    
    // Charset tag check
    if (result.charset.status === "good") {
      goodCount++;
      score += 33;
    } else if (result.charset.status === "warning") {
      score += 20;
    }
    
    // Language tag check
    if (result.language.status === "good") {
      goodCount++;
      score += 34;
    } else if (result.language.status === "warning") {
      score += 20;
    }
    
    let status: "good" | "warning" | "error" = "error";
    if (score >= 75) status = "good";
    else if (score >= 40) status = "warning";
    
    return {
      score,
      status,
      count: {
        total: totalTags,
        good: goodCount
      }
    };
  };
  
  const getRecommendationsStatus = () => {
    const recommendationCount = result.recommendations.length;
    let status: "good" | "warning" | "error" | "info" = "good";
    let score = 100;
    
    if (recommendationCount > 5) {
      status = "error";
      score = 25;
    } else if (recommendationCount > 2) {
      status = "warning";
      score = 60;
    } else if (recommendationCount > 0) {
      status = "info";
      score = 80;
    }
    
    return { status, score, count: recommendationCount };
  };
  
  const coreStatus = getCoreTagsStatus();
  const socialStatus = getSocialTagsStatus();
  const technicalStatus = getTechnicalTagsStatus();
  const recommendationsStatus = getRecommendationsStatus();
  
  const categories = [
    {
      label: "Core Meta Tags",
      score: coreStatus.score,
      status: coreStatus.status,
      description: "Essential tags like title and description",
      count: coreStatus.count
    },
    {
      label: "Social Media Tags",
      score: socialStatus.score,
      status: socialStatus.status,
      description: "Tags for social media previews",
      count: socialStatus.count
    },
    {
      label: "Technical Tags",
      score: technicalStatus.score,
      status: technicalStatus.status,
      description: "Technical SEO implementation",
      count: technicalStatus.count
    },
    {
      label: "Recommendations",
      score: recommendationsStatus.score,
      status: recommendationsStatus.status,
      description: recommendationsStatus.count === 0 
        ? "No improvements needed!" 
        : `${recommendationsStatus.count} improvements suggested`
    }
  ];

  return <CategorySummary categories={categories} />;
}
