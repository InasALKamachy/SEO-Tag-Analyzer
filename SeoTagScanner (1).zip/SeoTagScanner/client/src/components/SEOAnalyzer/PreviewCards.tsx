import React, { useState } from "react";
import { OpenGraphTags, TwitterTags } from "@/lib/types";
import { Image, Search, LayoutGrid, ChevronDown, ChevronUp } from "lucide-react";

interface PreviewCardsProps {
  title: {
    content: string;
    length: number;
    status: "good" | "warning" | "error";
  };
  description: {
    content: string | null;
    length: number;
    status: "good" | "warning" | "error";
  };
  url: string;
  openGraph: OpenGraphTags;
  twitter: TwitterTags;
}

export default function PreviewCards({ title, description, url, openGraph, twitter }: PreviewCardsProps) {
  const [expanded, setExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState<"google" | "facebook" | "twitter">("google");
  
  // Display hostname without protocol
  const displayUrl = url.replace(/^https?:\/\//, '');
  
  // Format URL for display in Google search result
  const formatDisplayUrl = (url: string) => {
    try {
      const urlObj = new URL(url);
      return `${urlObj.hostname}${urlObj.pathname}`;
    } catch (e) {
      return url;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden w-full">
      <div 
        className="px-3 py-2 border-b border-neutral-200 flex justify-between items-center cursor-pointer hover:bg-neutral-50"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-1.5">
          <LayoutGrid className="h-4 w-4 text-primary" />
          <h3 className="font-semibold text-neutral-800 text-sm">Search & Social Previews</h3>
        </div>
        {expanded ? <ChevronUp className="h-4 w-4 text-neutral-500" /> : <ChevronDown className="h-4 w-4 text-neutral-500" />}
      </div>
      
      {expanded && (
        <div className="p-3">
          {/* Preview Tabs */}
          <div className="flex border-b border-neutral-200 mb-3">
            <button 
              className={`px-2 py-1.5 text-xs font-medium relative ${activeTab === 'google' ? 'text-primary' : 'text-neutral-500 hover:text-neutral-800'}`}
              onClick={() => setActiveTab("google")}
            >
              <div className="flex items-center gap-1">
                <Search className="h-3 w-3" />
                <span>Google</span>
              </div>
              {activeTab === 'google' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"></div>}
            </button>
            <button 
              className={`px-2 py-1.5 text-xs font-medium relative ${activeTab === 'facebook' ? 'text-primary' : 'text-neutral-500 hover:text-neutral-800'}`}
              onClick={() => setActiveTab("facebook")}
            >
              <div className="flex items-center gap-1">
                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9.5 3H12V7H9.5C7.57 7 6 8.57 6 10.5V13H3V17H6V21H10V17H12.5L13 13H10V10.5C10 10.22 10.22 10 10.5 10H13V6.12C11.71 5.7 10.62 5.5 9.5 5.5C7.02 5.5 5 7.02 5 9.5V11H2V15H5V21H9V15H11.5L12 11H9V9.5C9 9.22 9.22 9 9.5 9H13" />
                </svg>
                <span>Facebook</span>
              </div>
              {activeTab === 'facebook' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"></div>}
            </button>
            <button 
              className={`px-2 py-1.5 text-xs font-medium relative ${activeTab === 'twitter' ? 'text-primary' : 'text-neutral-500 hover:text-neutral-800'}`}
              onClick={() => setActiveTab("twitter")}
            >
              <div className="flex items-center gap-1">
                <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22 5.8a8.49 8.49 0 0 1-2.36.64 4.13 4.13 0 0 0 1.81-2.27 8.21 8.21 0 0 1-2.61 1 4.1 4.1 0 0 0-7 3.74 11.64 11.64 0 0 1-8.45-4.29 4.16 4.16 0 0 0-.55 2.07 4.09 4.09 0 0 0 1.82 3.41 4.05 4.05 0 0 1-1.86-.51v.05a4.1 4.1 0 0 0 3.3 4 3.93 3.93 0 0 1-1.1.17 4 4 0 0 1-.77-.07 4.11 4.11 0 0 0 3.83 2.84A8.22 8.22 0 0 1 3 18.34a7.93 7.93 0 0 1-1-.06 11.57 11.57 0 0 0 6.29 1.85A11.59 11.59 0 0 0 20 8.45v-.53a8.43 8.43 0 0 0 2-2.12Z" />
                </svg>
                <span>Twitter</span>
              </div>
              {activeTab === 'twitter' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"></div>}
            </button>
          </div>
          
          {/* Google Search Preview */}
          {activeTab === "google" && (
            <div className="border border-neutral-200 rounded-lg p-2 relative bg-white overflow-hidden">
              <div className="absolute inset-0 h-1.5 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500"></div>
              <div className="relative pt-2">
                <div className="text-neutral-400 text-xs mb-1">Search appearance:</div>
                <div className="text-blue-600 text-sm font-medium line-clamp-1 hover:underline cursor-pointer">{title.content}</div>
                <div className="text-green-700 text-xs mt-0.5">{formatDisplayUrl(url)}</div>
                <div className="text-xs text-neutral-700 mt-0.5 line-clamp-2">{description.content || "No description available"}</div>
              </div>
            </div>
          )}
          
          {/* Facebook/Open Graph Preview */}
          {activeTab === "facebook" && (
            <div className="border border-neutral-200 rounded-lg overflow-hidden shadow-sm">
              <div className="h-6 bg-blue-600 flex items-center px-2">
                <svg className="h-3 w-3 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9.5 3H12V7H9.5C7.57 7 6 8.57 6 10.5V13H3V17H6V21H10V17H12.5L13 13H10V10.5C10 10.22 10.22 10 10.5 10H13V6.12C11.71 5.7 10.62 5.5 9.5 5.5C7.02 5.5 5 7.02 5 9.5V11H2V15H5V21H9V15H11.5L12 11H9V9.5C9 9.22 9.22 9 9.5 9H13" />
                </svg>
              </div>
              {openGraph.image ? (
                <div className="h-36 bg-neutral-100 flex items-center justify-center">
                  <img 
                    src={openGraph.image} 
                    alt="OpenGraph Preview" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.parentElement!.innerHTML = 
                        '<div class="w-full h-full flex items-center justify-center"><span class="text-2xl text-neutral-400"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg></span></div>';
                    }}
                  />
                </div>
              ) : (
                <div className="h-36 bg-neutral-100 flex flex-col items-center justify-center text-neutral-400 p-2 text-center">
                  <svg className="w-8 h-8 mb-1 text-neutral-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                    <circle cx="9" cy="9" r="2" />
                    <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                  </svg>
                  <span className="text-xs">No Open Graph image found</span>
                </div>
              )}
              <div className="p-2 border-t border-neutral-200">
                <div className="flex items-center">
                  <div className="h-6 w-6 bg-neutral-200 rounded-full mr-1.5 flex-shrink-0"></div>
                  <div>
                    <div className="text-neutral-800 font-medium text-xs">Page Name</div>
                    <div className="text-neutral-500 text-xs">Just now · <span>🌍</span></div>
                  </div>
                </div>
                <div className="mt-1.5 border border-neutral-200 rounded overflow-hidden">
                  <div className="text-neutral-800 font-medium p-2 text-xs line-clamp-1">{openGraph.title || title.content}</div>
                  <div className="text-neutral-600 text-xs px-2 pb-1.5 line-clamp-2">{openGraph.description || description.content || "No description available"}</div>
                  <div className="text-neutral-500 text-xs p-1.5 border-t border-neutral-200">{displayUrl}</div>
                </div>
              </div>
            </div>
          )}
          
          {/* Twitter Card Preview */}
          {activeTab === "twitter" && (
            <div className="border border-neutral-200 rounded-lg overflow-hidden shadow-sm bg-white">
              <div className="p-2 border-b border-neutral-200 flex items-center">
                <div className="h-6 w-6 bg-neutral-100 rounded-full mr-1.5 flex-shrink-0 border border-neutral-200"></div>
                <div>
                  <div className="text-neutral-800 font-medium text-xs">Display Name</div>
                  <div className="text-neutral-500 text-xs">@username</div>
                </div>
                <div className="ml-auto text-blue-400">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22 5.8a8.49 8.49 0 0 1-2.36.64 4.13 4.13 0 0 0 1.81-2.27 8.21 8.21 0 0 1-2.61 1 4.1 4.1 0 0 0-7 3.74 11.64 11.64 0 0 1-8.45-4.29 4.16 4.16 0 0 0-.55 2.07 4.09 4.09 0 0 0 1.82 3.41 4.05 4.05 0 0 1-1.86-.51v.05a4.1 4.1 0 0 0 3.3 4 3.93 3.93 0 0 1-1.1.17 4 4 0 0 1-.77-.07 4.11 4.11 0 0 0 3.83 2.84A8.22 8.22 0 0 1 3 18.34a7.93 7.93 0 0 1-1-.06 11.57 11.57 0 0 0 6.29 1.85A11.59 11.59 0 0 0 20 8.45v-.53a8.43 8.43 0 0 0 2-2.12Z" />
                  </svg>
                </div>
              </div>
              <div className="p-2">
                <p className="text-neutral-700 text-xs mb-1.5">Check out this page:</p>
                <div className="border border-neutral-200 rounded overflow-hidden">
                  {twitter.image ? (
                    <div className="h-24 bg-neutral-100 flex items-center justify-center">
                      <img 
                        src={twitter.image} 
                        alt="Twitter Card Preview" 
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.parentElement!.innerHTML = 
                            '<div class="w-full h-full flex items-center justify-center"><span class="text-2xl text-neutral-400"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg></span></div>';
                        }}
                      />
                    </div>
                  ) : (
                    <div className="h-24 bg-neutral-100 flex flex-col items-center justify-center text-neutral-400 p-2 text-center">
                      <svg className="w-6 h-6 mb-1 text-neutral-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                        <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                        <circle cx="9" cy="9" r="2" />
                        <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                      </svg>
                      <span className="text-xs">No Twitter Card image</span>
                    </div>
                  )}
                  <div className="p-2">
                    <div className="text-neutral-800 font-medium text-xs line-clamp-1">{twitter.title || openGraph.title || title.content}</div>
                    <div className="text-neutral-600 text-xs mt-0.5 line-clamp-2">{twitter.description || openGraph.description || description.content || "No description available"}</div>
                    <div className="text-neutral-500 text-xs mt-0.5">{displayUrl}</div>
                  </div>
                </div>
                <div className="flex justify-around mt-1.5 text-neutral-500 text-xs">
                  <div className="cursor-pointer hover:text-blue-400 transition-colors">💬</div>
                  <div className="cursor-pointer hover:text-green-400 transition-colors">🔄</div>
                  <div className="cursor-pointer hover:text-red-400 transition-colors">❤️</div>
                  <div className="cursor-pointer hover:text-blue-400 transition-colors">🔗</div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
