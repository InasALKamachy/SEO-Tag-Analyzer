export interface SEOAnalysisResult {
  url: string;
  score: number;
  metaTagsCount: number;
  title: {
    content: string;
    length: number;
    status: "good" | "warning" | "error";
    message?: string;
  };
  description: {
    content: string | null;
    length: number;
    status: "good" | "warning" | "error";
    message?: string;
  };
  viewport: {
    content: string | null;
    status: "good" | "warning" | "error";
    message?: string;
  };
  canonical: {
    content: string | null;
    status: "good" | "warning" | "error";
    message?: string;
  };
  robots: {
    content: string | null;
    status: "good" | "warning" | "error" | "not-required";
  };
  charset: {
    content: string | null;
    status: "good" | "warning" | "error";
  };
  language: {
    content: string | null;
    status: "good" | "warning" | "error";
  };
  openGraph: OpenGraphTags;
  twitter: TwitterTags;
  recommendations: Recommendation[];
  performance?: PerformanceMetrics;
  headers?: HeadersAnalysis;
  contentAnalysis?: ContentAnalysis;
}

export interface OpenGraphTags {
  title: string | null;
  description: string | null;
  image: string | null;
  url: string | null;
  type: string | null;
  siteName: string | null;
}

export interface TwitterTags {
  card: string | null;
  title: string | null;
  description: string | null;
  image: string | null;
  site: string | null;
  creator: string | null;
}

export interface Recommendation {
  title: string;
  description: string;
  example?: string;
  priority: "high" | "medium" | "low";
}

export interface PerformanceMetrics {
  loadTime?: number;
  resourceSize?: number;
  requestCount?: number;
  status: "good" | "warning" | "error";
  pageSizeKb?: number;
  recommendations?: Recommendation[];
}

export interface HeadersAnalysis {
  securityHeaders: {
    contentSecurityPolicy?: string | null;
    strictTransportSecurity?: string | null;
    xContentTypeOptions?: string | null;
    xFrameOptions?: string | null;
    referrerPolicy?: string | null;
    permissions?: string | null;
  };
  cacheHeaders: {
    cacheControl?: string | null;
    expires?: string | null;
    etag?: string | null;
    lastModified?: string | null;
  };
  status: "good" | "warning" | "error";
  recommendations?: Recommendation[];
}

export interface ContentAnalysis {
  headings: {
    h1Count: number;
    h2Count: number;
    h3Count: number;
    h1Content?: string[];
    hasProperStructure: boolean;
  };
  images: {
    count: number;
    withAlt: number;
    withoutAlt: number;
    altTextQuality?: "good" | "needs-improvement" | "poor";
  };
  links: {
    count: number;
    internal: number;
    external: number;
    broken?: number;
  };
  contentLength?: number;
  keywordDensity?: {
    [keyword: string]: number;
  };
  readabilityScore?: number;
  status: "good" | "warning" | "error";
  recommendations?: Recommendation[];
}

export interface CompetitorAnalysis {
  competitorUrl: string;
  score: number;
  keyMetaTags: {
    title?: string;
    description?: string;
  };
  comparison: {
    titleLength: { yours: number; competitor: number };
    descriptionLength: { yours: number; competitor: number };
    metaTagsCount: { yours: number; competitor: number };
    socialTags: { yours: number; competitor: number };
  };
}
